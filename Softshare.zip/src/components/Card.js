import { useMemo } from "react";
import "./Card.css";

const Card = ({
  prop,
  utilizadores,
  propAlignSelf,
  propPadding,
  propWidth,
  propMinWidth,
  propMarginLeft,
  card5Width,
  card5MinWidth,
  frameDivAlignSelf,
  divFlex,
  divMinWidth,
}) => {
  const card5Style = useMemo(() => {
    return {
      alignSelf: propAlignSelf,
      width: card5Width,
      minWidth: card5MinWidth,
    };
  }, [propAlignSelf, card5Width, card5MinWidth]);

  const topStyle = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const frameDivStyle = useMemo(() => {
    return {
      width: propWidth,
    };
  }, [propWidth]);

  const utilizadoresStyle = useMemo(() => {
    return {
      minWidth: propMinWidth,
      marginLeft: propMarginLeft,
    };
  }, [propMinWidth, propMarginLeft]);

  const frameDiv1Style = useMemo(() => {
    return {
      alignSelf: frameDivAlignSelf,
    };
  }, [frameDivAlignSelf]);

  const divStyle = useMemo(() => {
    return {
      flex: divFlex,
      minWidth: divMinWidth,
    };
  }, [divFlex, divMinWidth]);

  return (
    <div className="card-5" style={card5Style}>
      <div className="bg1" />
      <div className="top-container">
        <div className="top1" style={topStyle}>
          <img className="data-icon1" loading="lazy" alt="" src="/data.svg" />
          <div className="top-child" style={frameDivStyle}>
            <div className="bg-light-grey-group" style={frameDiv1Style}>
              <div className="bg-light-grey1" />
              <div className="div46" style={divStyle}>
                {prop}
              </div>
            </div>
          </div>
          <div className="utilizadores1" style={utilizadoresStyle}>
            {utilizadores}
          </div>
        </div>
      </div>
      <div className="frame-parent9">
        <div className="vector-container">
          <img
            className="frame-child8"
            loading="lazy"
            alt=""
            src="/line-3.svg"
          />
          <div className="viseu-container">
            <div className="viseu3">Viseu</div>
          </div>
          <div className="wrapper67">
            <div className="div47">19%</div>
          </div>
        </div>
        <div className="frame-child9" />
        <div className="vector-parent1">
          <img
            className="frame-child10"
            loading="lazy"
            alt=""
            src="/line-3-1.svg"
          />
          <div className="lisboa-wrapper">
            <div className="lisboa">Lisboa</div>
          </div>
          <div className="wrapper68">
            <div className="div48">32%</div>
          </div>
        </div>
        <div className="frame-child11" />
        <div className="vector-parent2">
          <img
            className="frame-child12"
            loading="lazy"
            alt=""
            src="/line-3-2.svg"
          />
          <div className="porto-wrapper">
            <div className="porto">Porto</div>
          </div>
          <div className="wrapper69">
            <div className="div49">29%</div>
          </div>
        </div>
        <div className="frame-child13" />
        <div className="vector-parent3">
          <img
            className="frame-child14"
            loading="lazy"
            alt=""
            src="/line-3-3.svg"
          />
          <div className="tomar-wrapper">
            <div className="tomar">Tomar</div>
          </div>
          <div className="wrapper70">
            <div className="div50">12%</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;
