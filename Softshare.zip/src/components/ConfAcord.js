import "./ConfAcord.css";

const ConfAcord = ({ iconWrapper }) => {
  return (
    <div className="conf-acord10">
      <div className="aprovacoes7">
        <div className="wrapper60">
          <div className="icon70">
            <div className="width-change-size-here131">
              <div className="ignore532" />
              <div className="ignore533" />
            </div>
            <div className="icon-wrapper-h131">
              <div className="height-change-size-here131">
                <div className="ignore534" />
                <div className="ignore535" />
              </div>
              <img className="icon-wrapper137" alt="" src={iconWrapper} />
            </div>
          </div>
          <div className="text218">
            <div className="data-aggregator2">Formulários</div>
          </div>
        </div>
        <div className="arrow55">
          <div className="width-change-size-here132">
            <div className="ignore536" />
            <div className="ignore537" />
          </div>
          <div className="icon-wrapper-h132">
            <div className="height-change-size-here132">
              <div className="ignore538" />
              <div className="ignore539" />
            </div>
            <img
              className="icon-wrapper138"
              alt=""
              src="/iconwrapper-21@2x.png"
            />
          </div>
        </div>
      </div>
      <div className="permisses7">
        <div className="wrapper61">
          <div className="icon71">
            <div className="width-change-size-here133">
              <div className="ignore540" />
              <div className="ignore541" />
            </div>
            <div className="icon-wrapper-h133">
              <div className="height-change-size-here133">
                <div className="ignore542" />
                <div className="ignore543" />
              </div>
              <img
                className="icon-wrapper139"
                alt=""
                src="/iconwrapper-121@2x.png"
              />
            </div>
          </div>
          <div className="text219">
            <div className="parallel-processor">Utilizadores</div>
          </div>
        </div>
        <div className="arrow56">
          <div className="width-change-size-here134">
            <div className="ignore544" />
            <div className="ignore545" />
          </div>
          <div className="icon-wrapper-h134">
            <div className="height-change-size-here134">
              <div className="ignore546" />
              <div className="ignore547" />
            </div>
            <img
              className="icon-wrapper140"
              alt=""
              src="/iconwrapper-21@2x.png"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfAcord;
