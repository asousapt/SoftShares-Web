import "./FrameComponent.css";

const FrameComponent = () => {
  return (
    <div className="function-composer">
      <h1 className="admin-dashboard4">Painel de controlo</h1>
      <div className="condition-combiner">
        <div className="loop-counter">
          <div className="segment-43">
            <div className="icon-container3">
              <div className="state-layer3">
                <img
                  className="icon77"
                  loading="lazy"
                  alt=""
                  src="/icon1@2x.png"
                />
                <div className="badge3">
                  <div className="spacer7" />
                </div>
              </div>
            </div>
          </div>
          <img
            className="user-cicrle-duotone-icon3"
            loading="lazy"
            alt=""
            src="/user-cicrle-duotone@2x.png"
          />
        </div>
      </div>
    </div>
  );
};

export default FrameComponent;
