import ConfAcord from "./ConfAcord";
import "./FrameComponent1.css";

const FrameComponent1 = () => {
  return (
    <div className="logic-tree">
      <div className="output-set-parent">
        <div className="output-set">
          <h2 className="viseu2">Viseu</h2>
        </div>
        <h1 className="bem-vindo3">Bem-vindo</h1>
      </div>
      <div className="navbar-14">
        <div className="navbar4">
          <div className="atoms-colors-gray-34">
            <div className="atoms-colors-black4" />
          </div>
          <div className="button37">
            <img
              className="atoms-buttons-resources4"
              alt=""
              src="/atoms--buttons---resources--shapes--radius-bordered@2x.png"
            />
            <div className="atoms-buttons-labels-ac4">
              <div className="div39">Login</div>
            </div>
          </div>
          <div className="links5">
            <div className="div40">Contact</div>
            <div className="div41">Pricing</div>
            <div className="div42">Press</div>
            <div className="div43">Features</div>
            <div className="div44">How it works</div>
            <div className="div45">Home</div>
          </div>
          <img className="logo-icon4" alt="" src="/logo@2x.png" />
        </div>
      </div>
      <div className="user-container">
        <div className="user4">@user</div>
      </div>
      <div className="user5">@user</div>
      <div className="logic-tree-inner">
        <div className="dashboard-container">
          <div className="dashboard3">
            <div className="configuracoes29">
              <div className="wrapper62">
                <div className="icon72">
                  <div className="width-change-size-here135">
                    <div className="ignore548" />
                    <div className="ignore549" />
                  </div>
                  <div className="icon-wrapper-h135">
                    <div className="height-change-size-here135">
                      <div className="ignore550" />
                      <div className="ignore551" />
                    </div>
                    <img
                      className="icon-wrapper141"
                      alt=""
                      src="/iconwrapper-22@2x.png"
                    />
                  </div>
                </div>
                <div className="text220">
                  <div className="text221">Dashboard</div>
                </div>
              </div>
              <div className="arrow57">
                <div className="width-change-size-here136">
                  <div className="ignore552" />
                  <div className="ignore553" />
                </div>
                <div className="icon-wrapper-h136">
                  <div className="height-change-size-here136">
                    <div className="ignore554" />
                    <div className="ignore555" />
                  </div>
                  <img
                    className="icon-wrapper142"
                    alt=""
                    src="/iconwrapper-20@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="estatisticas3">
            <div className="configuracoes30">
              <div className="wrapper63">
                <div className="icon73">
                  <div className="width-change-size-here137">
                    <div className="ignore556" />
                    <div className="ignore557" />
                  </div>
                  <div className="icon-wrapper-h137">
                    <div className="height-change-size-here137">
                      <div className="ignore558" />
                      <div className="ignore559" />
                    </div>
                    <img
                      className="icon-wrapper143"
                      alt=""
                      src="/iconwrapper-22@2x.png"
                    />
                  </div>
                </div>
                <div className="text222">
                  <div className="text223">Estatísticas</div>
                </div>
              </div>
              <div className="arrow58">
                <div className="width-change-size-here138">
                  <div className="ignore560" />
                  <div className="ignore561" />
                </div>
                <div className="icon-wrapper-h138">
                  <div className="height-change-size-here138">
                    <div className="ignore562" />
                    <div className="ignore563" />
                  </div>
                  <img
                    className="icon-wrapper144"
                    alt=""
                    src="/iconwrapper-21@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="listagens3">
            <div className="configuracoes31">
              <div className="wrapper64">
                <div className="icon74">
                  <div className="width-change-size-here139">
                    <div className="ignore564" />
                    <div className="ignore565" />
                  </div>
                  <div className="icon-wrapper-h139">
                    <div className="height-change-size-here139">
                      <div className="ignore566" />
                      <div className="ignore567" />
                    </div>
                    <img
                      className="icon-wrapper145"
                      alt=""
                      src="/iconwrapper-22@2x.png"
                    />
                  </div>
                </div>
                <div className="text224">
                  <div className="text225">Listagem</div>
                </div>
              </div>
              <div className="arrow59">
                <div className="width-change-size-here140">
                  <div className="ignore568" />
                  <div className="ignore569" />
                </div>
                <div className="icon-wrapper-h140">
                  <div className="height-change-size-here140">
                    <div className="ignore570" />
                    <div className="ignore571" />
                  </div>
                  <img
                    className="icon-wrapper146"
                    alt=""
                    src="/iconwrapper-21@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="moderacao3">
            <div className="configuracoes32">
              <div className="wrapper65">
                <div className="icon75">
                  <div className="width-change-size-here141">
                    <div className="ignore572" />
                    <div className="ignore573" />
                  </div>
                  <div className="icon-wrapper-h141">
                    <div className="height-change-size-here141">
                      <div className="ignore574" />
                      <div className="ignore575" />
                    </div>
                    <img
                      className="icon-wrapper147"
                      loading="lazy"
                      alt=""
                      src="/iconwrapper-22@2x.png"
                    />
                  </div>
                </div>
                <div className="text226">
                  <div className="text227">Moderação</div>
                </div>
              </div>
              <div className="arrow60">
                <div className="width-change-size-here142">
                  <div className="ignore576" />
                  <div className="ignore577" />
                </div>
                <div className="icon-wrapper-h142">
                  <div className="height-change-size-here142">
                    <div className="ignore578" />
                    <div className="ignore579" />
                  </div>
                  <img
                    className="icon-wrapper148"
                    alt=""
                    src="/iconwrapper-21@2x.png"
                  />
                </div>
              </div>
            </div>
            <ConfAcord iconWrapper="/iconwrapper-22@2x.png" />
          </div>
          <div className="configuraes3">
            <div className="configuracoes33">
              <div className="wrapper66">
                <div className="icon76">
                  <div className="width-change-size-here143">
                    <div className="ignore580" />
                    <div className="ignore581" />
                  </div>
                  <div className="icon-wrapper-h143">
                    <div className="height-change-size-here143">
                      <div className="ignore582" />
                      <div className="ignore583" />
                    </div>
                    <img
                      className="icon-wrapper149"
                      loading="lazy"
                      alt=""
                      src="/iconwrapper-22@2x.png"
                    />
                  </div>
                </div>
                <div className="text228">
                  <div className="text229">Configuração</div>
                </div>
              </div>
              <div className="arrow61">
                <div className="width-change-size-here144">
                  <div className="ignore584" />
                  <div className="ignore585" />
                </div>
                <div className="icon-wrapper-h144">
                  <div className="height-change-size-here144">
                    <div className="ignore586" />
                    <div className="ignore587" />
                  </div>
                  <img
                    className="icon-wrapper150"
                    alt=""
                    src="/iconwrapper-21@2x.png"
                  />
                </div>
              </div>
            </div>
            <ConfAcord iconWrapper="/iconwrapper-121@2x.png" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default FrameComponent1;
