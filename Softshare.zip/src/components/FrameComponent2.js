import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./FrameComponent2.css";

const FrameComponent2 = () => {
  const navigate = useNavigate();

  const onDenunciassContainerClick = useCallback(() => {
    navigate("/estatsticas-de-denuncias");
  }, [navigate]);

  return (
    <div className="navbar-1-group">
      <div className="navbar-12">
        <div className="navbar1">
          <div className="atoms-colors-gray-31">
            <div className="atoms-colors-black1" />
          </div>
          <div className="button34">
            <img
              className="atoms-buttons-resources1"
              alt=""
              src="/atoms--buttons---resources--shapes--radius-bordered@2x.png"
            />
            <div className="atoms-buttons-labels-ac1">
              <div className="div18">Login</div>
            </div>
          </div>
          <div className="links2">
            <div className="div19">Contact</div>
            <div className="div20">Pricing</div>
            <div className="div21">Press</div>
            <div className="div22">Features</div>
            <div className="div23">How it works</div>
            <div className="div24">Home</div>
          </div>
          <img className="logo-icon1" alt="" src="/logo@2x.png" />
        </div>
      </div>
      <h1 className="bem-vindo1">Bem-vindo</h1>
      <div className="input-provider">
        <div className="user1">@user</div>
        <div className="error-handler1">
          <div className="user2">@user</div>
        </div>
      </div>
      <div className="connection-point">
        <form className="conditional-branch1">
          <div className="dashboard1">
            <div className="configuracoes11">
              <div className="wrapper32">
                <div className="text170">
                  <div className="text171">Dashboard</div>
                </div>
              </div>
              <div className="arrow27">
                <div className="width-change-size-here77">
                  <div className="ignore316" />
                  <div className="ignore317" />
                </div>
                <div className="icon-wrapper-h77">
                  <div className="height-change-size-here77">
                    <div className="ignore318" />
                    <div className="ignore319" />
                  </div>
                  <img
                    className="icon-wrapper83"
                    alt=""
                    src="/iconwrapper-2@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="conf-acord3">
              <div className="aprovacoes2">
                <div className="wrapper33">
                  <div className="icon43">
                    <div className="width-change-size-here78">
                      <div className="ignore320" />
                      <div className="ignore321" />
                    </div>
                    <div className="icon-wrapper-h78">
                      <div className="height-change-size-here78">
                        <div className="ignore322" />
                        <div className="ignore323" />
                      </div>
                      <img
                        className="icon-wrapper84"
                        alt=""
                        src="/iconwrapper-3@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text172">
                    <div className="text173">Formulários</div>
                  </div>
                </div>
                <div className="arrow28">
                  <div className="width-change-size-here79">
                    <div className="ignore324" />
                    <div className="ignore325" />
                  </div>
                  <div className="icon-wrapper-h79">
                    <div className="height-change-size-here79">
                      <div className="ignore326" />
                      <div className="ignore327" />
                    </div>
                    <img
                      className="icon-wrapper85"
                      alt=""
                      src="/iconwrapper-2@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="permisses2">
                <div className="wrapper34">
                  <div className="icon44">
                    <div className="width-change-size-here80">
                      <div className="ignore328" />
                      <div className="ignore329" />
                    </div>
                    <div className="icon-wrapper-h80">
                      <div className="height-change-size-here80">
                        <div className="ignore330" />
                        <div className="ignore331" />
                      </div>
                      <img
                        className="icon-wrapper86"
                        alt=""
                        src="/iconwrapper-3@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text174">
                    <div className="text175">Utilizadores</div>
                  </div>
                </div>
                <div className="arrow29">
                  <div className="width-change-size-here81">
                    <div className="ignore332" />
                    <div className="ignore333" />
                  </div>
                  <div className="icon-wrapper-h81">
                    <div className="height-change-size-here81">
                      <div className="ignore334" />
                      <div className="ignore335" />
                    </div>
                    <img
                      className="icon-wrapper87"
                      alt=""
                      src="/iconwrapper-2@2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="estatisticas1">
            <div className="configuracoes12">
              <div className="wrapper35">
                <div className="icon45">
                  <div className="width-change-size-here82">
                    <div className="ignore336" />
                    <div className="ignore337" />
                  </div>
                  <div className="icon-wrapper-h82">
                    <div className="height-change-size-here82">
                      <div className="ignore338" />
                      <div className="ignore339" />
                    </div>
                    <img
                      className="icon-wrapper88"
                      alt=""
                      src="/iconwrapper-7@2x.png"
                    />
                  </div>
                </div>
                <div className="text176">
                  <div className="selection-sort">Estatísticas</div>
                </div>
              </div>
              <div className="arrow30">
                <div className="width-change-size-here83">
                  <div className="ignore340" />
                  <div className="ignore341" />
                </div>
                <div className="icon-wrapper-h83">
                  <div className="height-change-size-here83">
                    <div className="ignore342" />
                    <div className="ignore343" />
                  </div>
                  <img
                    className="icon-wrapper89"
                    alt=""
                    src="/iconwrapper-8@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="conf-acord4">
              <div className="utilizadores">
                <div className="configuracoes13">
                  <div className="wrapper36">
                    <div className="icon46">
                      <div className="width-change-size-here84">
                        <div className="ignore344" />
                        <div className="ignore345" />
                      </div>
                      <div className="icon-wrapper-h84">
                        <div className="height-change-size-here84">
                          <div className="ignore346" />
                          <div className="ignore347" />
                        </div>
                        <img
                          className="icon-wrapper90"
                          loading="lazy"
                          alt=""
                          src="/iconwrapper-3@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text177">
                      <div className="error-handler2">Utilizadores</div>
                    </div>
                  </div>
                  <div className="arrow31">
                    <div className="width-change-size-here85">
                      <div className="ignore348" />
                      <div className="ignore349" />
                    </div>
                    <div className="icon-wrapper-h85">
                      <div className="height-change-size-here85">
                        <div className="ignore350" />
                        <div className="ignore351" />
                      </div>
                      <img
                        className="icon-wrapper91"
                        alt=""
                        src="/iconwrapper-2@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="denunciass" onClick={onDenunciassContainerClick}>
                <div className="configuracoes14">
                  <div className="wrapper37">
                    <div className="icon47">
                      <div className="width-change-size-here86">
                        <div className="ignore352" />
                        <div className="ignore353" />
                      </div>
                      <div className="icon-wrapper-h86">
                        <div className="height-change-size-here86">
                          <div className="ignore354" />
                          <div className="ignore355" />
                        </div>
                        <img
                          className="icon-wrapper92"
                          alt=""
                          src="/iconwrapper-111@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text178">
                      <div className="text179">Denúncias</div>
                    </div>
                  </div>
                  <div className="arrow32">
                    <div className="width-change-size-here87">
                      <div className="ignore356" />
                      <div className="ignore357" />
                    </div>
                    <div className="icon-wrapper-h87">
                      <div className="height-change-size-here87">
                        <div className="ignore358" />
                        <div className="ignore359" />
                      </div>
                      <img
                        className="icon-wrapper93"
                        alt=""
                        src="/iconwrapper-12@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="listagens1">
            <div className="configuracoes15">
              <div className="wrapper38">
                <div className="icon48">
                  <div className="width-change-size-here88">
                    <div className="ignore360" />
                    <div className="ignore361" />
                  </div>
                  <div className="icon-wrapper-h88">
                    <div className="height-change-size-here88">
                      <div className="ignore362" />
                      <div className="ignore363" />
                    </div>
                    <img
                      className="icon-wrapper94"
                      alt=""
                      src="/iconwrapper-3@2x.png"
                    />
                  </div>
                </div>
                <div className="text180">
                  <div className="grid-system">Listagem</div>
                </div>
              </div>
              <div className="arrow33">
                <div className="width-change-size-here89">
                  <div className="ignore364" />
                  <div className="ignore365" />
                </div>
                <div className="icon-wrapper-h89">
                  <div className="height-change-size-here89">
                    <div className="ignore366" />
                    <div className="ignore367" />
                  </div>
                  <img
                    className="icon-wrapper95"
                    alt=""
                    src="/iconwrapper-2@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="moderacao1">
            <div className="configuracoes16">
              <div className="wrapper39">
                <div className="icon49">
                  <div className="width-change-size-here90">
                    <div className="ignore368" />
                    <div className="ignore369" />
                  </div>
                  <div className="icon-wrapper-h90">
                    <div className="height-change-size-here90">
                      <div className="ignore370" />
                      <div className="ignore371" />
                    </div>
                    <img
                      className="icon-wrapper96"
                      loading="lazy"
                      alt=""
                      src="/iconwrapper-3@2x.png"
                    />
                  </div>
                </div>
                <div className="text181">
                  <div className="text182">Moderação</div>
                </div>
              </div>
              <div className="arrow34">
                <div className="width-change-size-here91">
                  <div className="ignore372" />
                  <div className="ignore373" />
                </div>
                <div className="icon-wrapper-h91">
                  <div className="height-change-size-here91">
                    <div className="ignore374" />
                    <div className="ignore375" />
                  </div>
                  <img
                    className="icon-wrapper97"
                    alt=""
                    src="/iconwrapper-2@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="conf-acord5">
              <div className="aprovacoes3">
                <div className="wrapper40">
                  <div className="icon50">
                    <div className="width-change-size-here92">
                      <div className="ignore376" />
                      <div className="ignore377" />
                    </div>
                    <div className="icon-wrapper-h92">
                      <div className="height-change-size-here92">
                        <div className="ignore378" />
                        <div className="ignore379" />
                      </div>
                      <img
                        className="icon-wrapper98"
                        alt=""
                        src="/iconwrapper-3@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text183">
                    <div className="blend-mode">Formulários</div>
                  </div>
                </div>
                <div className="arrow35">
                  <div className="width-change-size-here93">
                    <div className="ignore380" />
                    <div className="ignore381" />
                  </div>
                  <div className="icon-wrapper-h93">
                    <div className="height-change-size-here93">
                      <div className="ignore382" />
                      <div className="ignore383" />
                    </div>
                    <img
                      className="icon-wrapper99"
                      alt=""
                      src="/iconwrapper-2@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="permisses3">
                <div className="wrapper41">
                  <div className="icon51">
                    <div className="width-change-size-here94">
                      <div className="ignore384" />
                      <div className="ignore385" />
                    </div>
                    <div className="icon-wrapper-h94">
                      <div className="height-change-size-here94">
                        <div className="ignore386" />
                        <div className="ignore387" />
                      </div>
                      <img
                        className="icon-wrapper100"
                        alt=""
                        src="/iconwrapper-3@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text184">
                    <div className="list">Utilizadores</div>
                  </div>
                </div>
                <div className="arrow36">
                  <div className="width-change-size-here95">
                    <div className="ignore388" />
                    <div className="ignore389" />
                  </div>
                  <div className="icon-wrapper-h95">
                    <div className="height-change-size-here95">
                      <div className="ignore390" />
                      <div className="ignore391" />
                    </div>
                    <img
                      className="icon-wrapper101"
                      alt=""
                      src="/iconwrapper-2@2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="configuraes1">
            <div className="configuracoes17">
              <div className="wrapper42">
                <div className="icon52">
                  <div className="width-change-size-here96">
                    <div className="ignore392" />
                    <div className="ignore393" />
                  </div>
                  <div className="icon-wrapper-h96">
                    <div className="height-change-size-here96">
                      <div className="ignore394" />
                      <div className="ignore395" />
                    </div>
                    <img
                      className="icon-wrapper102"
                      loading="lazy"
                      alt=""
                      src="/iconwrapper-3@2x.png"
                    />
                  </div>
                </div>
                <div className="text185">
                  <div className="text186">Configuração</div>
                </div>
              </div>
              <div className="arrow37">
                <div className="width-change-size-here97">
                  <div className="ignore396" />
                  <div className="ignore397" />
                </div>
                <div className="icon-wrapper-h97">
                  <div className="height-change-size-here97">
                    <div className="ignore398" />
                    <div className="ignore399" />
                  </div>
                  <img
                    className="icon-wrapper103"
                    alt=""
                    src="/iconwrapper-2@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="conf-acord6">
              <div className="aprovacoes4">
                <div className="wrapper43">
                  <div className="icon53">
                    <div className="width-change-size-here98">
                      <div className="ignore400" />
                      <div className="ignore401" />
                    </div>
                    <div className="icon-wrapper-h98">
                      <div className="height-change-size-here98">
                        <div className="ignore402" />
                        <div className="ignore403" />
                      </div>
                      <img
                        className="icon-wrapper104"
                        alt=""
                        src="/iconwrapper-3@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text187">
                    <div className="text188">Formulários</div>
                  </div>
                </div>
                <div className="arrow38">
                  <div className="width-change-size-here99">
                    <div className="ignore404" />
                    <div className="ignore405" />
                  </div>
                  <div className="icon-wrapper-h99">
                    <div className="height-change-size-here99">
                      <div className="ignore406" />
                      <div className="ignore407" />
                    </div>
                    <img
                      className="icon-wrapper105"
                      loading="lazy"
                      alt=""
                      src="/iconwrapper-2@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="permisses4">
                <div className="wrapper44">
                  <div className="icon54">
                    <div className="width-change-size-here100">
                      <div className="ignore408" />
                      <div className="ignore409" />
                    </div>
                    <div className="icon-wrapper-h100">
                      <div className="height-change-size-here100">
                        <div className="ignore410" />
                        <div className="ignore411" />
                      </div>
                      <img
                        className="icon-wrapper106"
                        alt=""
                        src="/iconwrapper-3@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text189">
                    <div className="text190">Utilizadores</div>
                  </div>
                </div>
                <div className="arrow39">
                  <div className="width-change-size-here101">
                    <div className="ignore412" />
                    <div className="ignore413" />
                  </div>
                  <div className="icon-wrapper-h101">
                    <div className="height-change-size-here101">
                      <div className="ignore414" />
                      <div className="ignore415" />
                    </div>
                    <img
                      className="icon-wrapper107"
                      loading="lazy"
                      alt=""
                      src="/iconwrapper-2@2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FrameComponent2;
