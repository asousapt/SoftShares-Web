import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./FrameComponent3.css";

const FrameComponent3 = () => {
  const navigate = useNavigate();

  const onUsersContainerClick = useCallback(() => {
    navigate("/lista-utilizadores");
  }, [navigate]);

  return (
    <div className="navbar-1-container">
      <div className="navbar-13">
        <div className="navbar3">
          <div className="atoms-colors-gray-33">
            <div className="atoms-colors-black3" />
          </div>
          <div className="button36">
            <img
              className="atoms-buttons-resources3"
              alt=""
              src="/atoms--buttons---resources--shapes--radius-bordered@2x.png"
            />
            <div className="atoms-buttons-labels-ac3">
              <div className="div32">Login</div>
            </div>
          </div>
          <div className="links4">
            <div className="div33">Contact</div>
            <div className="div34">Pricing</div>
            <div className="div35">Press</div>
            <div className="div36">Features</div>
            <div className="div37">How it works</div>
            <div className="div38">Home</div>
          </div>
          <img className="logo-icon3" alt="" src="/logo@2x.png" />
        </div>
      </div>
      <div className="frame-parent8">
        <div className="viseu-wrapper">
          <div className="viseu1">Viseu</div>
        </div>
        <h1 className="bem-vindo2">Bem-vindo</h1>
      </div>
      <div className="user-wrapper">
        <div className="user3">@user</div>
      </div>
      <div className="frame-wrapper4">
        <nav className="dashboard-group">
          <div className="dashboard2">
            <div className="configuracoes18">
              <div className="wrapper45">
                <div className="text191">
                  <div className="logic-gate1">Dashboard</div>
                </div>
              </div>
              <div className="arrow40">
                <div className="width-change-size-here102">
                  <div className="ignore416" />
                  <div className="ignore417" />
                </div>
                <div className="icon-wrapper-h102">
                  <div className="height-change-size-here102">
                    <div className="ignore418" />
                    <div className="ignore419" />
                  </div>
                  <img
                    className="icon-wrapper108"
                    alt=""
                    src="/iconwrapper-21@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="conf-acord7">
              <div className="aprovacoes5">
                <div className="wrapper46">
                  <div className="icon55">
                    <div className="width-change-size-here103">
                      <div className="ignore420" />
                      <div className="ignore421" />
                    </div>
                    <div className="icon-wrapper-h103">
                      <div className="height-change-size-here103">
                        <div className="ignore422" />
                        <div className="ignore423" />
                      </div>
                      <img
                        className="icon-wrapper109"
                        alt=""
                        src="/iconwrapper-33@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text192">
                    <div className="text193">Formulários</div>
                  </div>
                </div>
                <div className="arrow41">
                  <div className="width-change-size-here104">
                    <div className="ignore424" />
                    <div className="ignore425" />
                  </div>
                  <div className="icon-wrapper-h104">
                    <div className="height-change-size-here104">
                      <div className="ignore426" />
                      <div className="ignore427" />
                    </div>
                    <img
                      className="icon-wrapper110"
                      alt=""
                      src="/iconwrapper-21@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="permisses5">
                <div className="wrapper47">
                  <div className="icon56">
                    <div className="width-change-size-here105">
                      <div className="ignore428" />
                      <div className="ignore429" />
                    </div>
                    <div className="icon-wrapper-h105">
                      <div className="height-change-size-here105">
                        <div className="ignore430" />
                        <div className="ignore431" />
                      </div>
                      <img
                        className="icon-wrapper111"
                        alt=""
                        src="/iconwrapper-33@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text194">
                    <div className="text195">Utilizadores</div>
                  </div>
                </div>
                <div className="arrow42">
                  <div className="width-change-size-here106">
                    <div className="ignore432" />
                    <div className="ignore433" />
                  </div>
                  <div className="icon-wrapper-h106">
                    <div className="height-change-size-here106">
                      <div className="ignore434" />
                      <div className="ignore435" />
                    </div>
                    <img
                      className="icon-wrapper112"
                      alt=""
                      src="/iconwrapper-21@2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="estatisticas2">
            <div className="configuracoes19">
              <div className="wrapper48">
                <div className="icon57">
                  <div className="width-change-size-here107">
                    <div className="ignore436" />
                    <div className="ignore437" />
                  </div>
                  <div className="icon-wrapper-h107">
                    <div className="height-change-size-here107">
                      <div className="ignore438" />
                      <div className="ignore439" />
                    </div>
                    <img
                      className="icon-wrapper113"
                      alt=""
                      src="/iconwrapper-33@2x.png"
                    />
                  </div>
                </div>
                <div className="text196">
                  <div className="text197">Estatísticas</div>
                </div>
              </div>
              <div className="arrow43">
                <div className="width-change-size-here108">
                  <div className="ignore440" />
                  <div className="ignore441" />
                </div>
                <div className="icon-wrapper-h108">
                  <div className="height-change-size-here108">
                    <div className="ignore442" />
                    <div className="ignore443" />
                  </div>
                  <img
                    className="icon-wrapper114"
                    alt=""
                    src="/iconwrapper-21@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="listagens2">
            <div className="configuracoes20">
              <div className="wrapper49">
                <div className="icon58">
                  <div className="width-change-size-here109">
                    <div className="ignore444" />
                    <div className="ignore445" />
                  </div>
                  <div className="icon-wrapper-h109">
                    <div className="height-change-size-here109">
                      <div className="ignore446" />
                      <div className="ignore447" />
                    </div>
                    <img
                      className="icon-wrapper115"
                      alt=""
                      src="/iconwrapper-33@2x.png"
                    />
                  </div>
                </div>
                <div className="text198">
                  <div className="text199">Listagem</div>
                </div>
              </div>
              <div className="arrow44">
                <div className="width-change-size-here110">
                  <div className="ignore448" />
                  <div className="ignore449" />
                </div>
                <div className="icon-wrapper-h110">
                  <div className="height-change-size-here110">
                    <div className="ignore450" />
                    <div className="ignore451" />
                  </div>
                  <img
                    className="icon-wrapper116"
                    alt=""
                    src="/iconwrapper-21@2x.png"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="moderacao2">
            <div className="configuracoes21">
              <div className="wrapper50">
                <div className="icon59">
                  <div className="width-change-size-here111">
                    <div className="ignore452" />
                    <div className="ignore453" />
                  </div>
                  <div className="icon-wrapper-h111">
                    <div className="height-change-size-here111">
                      <div className="ignore454" />
                      <div className="ignore455" />
                    </div>
                    <img
                      className="icon-wrapper117"
                      loading="lazy"
                      alt=""
                      src="/iconwrapper-33@2x.png"
                    />
                  </div>
                </div>
                <div className="text200">
                  <div className="text201">Moderação</div>
                </div>
              </div>
              <div className="arrow45">
                <div className="width-change-size-here112">
                  <div className="ignore456" />
                  <div className="ignore457" />
                </div>
                <div className="icon-wrapper-h112">
                  <div className="height-change-size-here112">
                    <div className="ignore458" />
                    <div className="ignore459" />
                  </div>
                  <img
                    className="icon-wrapper118"
                    loading="lazy"
                    alt=""
                    src="/iconwrapper-21@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="conf-acord8">
              <div className="aprovacoes6">
                <div className="wrapper51">
                  <div className="icon60">
                    <div className="width-change-size-here113">
                      <div className="ignore460" />
                      <div className="ignore461" />
                    </div>
                    <div className="icon-wrapper-h113">
                      <div className="height-change-size-here113">
                        <div className="ignore462" />
                        <div className="ignore463" />
                      </div>
                      <img
                        className="icon-wrapper119"
                        alt=""
                        src="/iconwrapper-33@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text202">
                    <div className="text203">Formulários</div>
                  </div>
                </div>
                <div className="arrow46">
                  <div className="width-change-size-here114">
                    <div className="ignore464" />
                    <div className="ignore465" />
                  </div>
                  <div className="icon-wrapper-h114">
                    <div className="height-change-size-here114">
                      <div className="ignore466" />
                      <div className="ignore467" />
                    </div>
                    <img
                      className="icon-wrapper120"
                      alt=""
                      src="/iconwrapper-21@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="permisses6">
                <div className="wrapper52">
                  <div className="icon61">
                    <div className="width-change-size-here115">
                      <div className="ignore468" />
                      <div className="ignore469" />
                    </div>
                    <div className="icon-wrapper-h115">
                      <div className="height-change-size-here115">
                        <div className="ignore470" />
                        <div className="ignore471" />
                      </div>
                      <img
                        className="icon-wrapper121"
                        alt=""
                        src="/iconwrapper-33@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text204">
                    <div className="text205">Utilizadores</div>
                  </div>
                </div>
                <div className="arrow47">
                  <div className="width-change-size-here116">
                    <div className="ignore472" />
                    <div className="ignore473" />
                  </div>
                  <div className="icon-wrapper-h116">
                    <div className="height-change-size-here116">
                      <div className="ignore474" />
                      <div className="ignore475" />
                    </div>
                    <img
                      className="icon-wrapper122"
                      alt=""
                      src="/iconwrapper-21@2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="configuraes2">
            <div className="configuracoes22">
              <div className="wrapper53">
                <div className="icon62">
                  <div className="width-change-size-here117">
                    <div className="ignore476" />
                    <div className="ignore477" />
                  </div>
                  <div className="icon-wrapper-h117">
                    <div className="height-change-size-here117">
                      <div className="ignore478" />
                      <div className="ignore479" />
                    </div>
                    <img
                      className="icon-wrapper123"
                      loading="lazy"
                      alt=""
                      src="/iconwrapper-171@2x.png"
                    />
                  </div>
                </div>
                <div className="text206">
                  <div className="path-manager">Configuração</div>
                </div>
              </div>
              <div className="arrow48">
                <div className="width-change-size-here118">
                  <div className="ignore480" />
                  <div className="ignore481" />
                </div>
                <div className="icon-wrapper-h118">
                  <div className="height-change-size-here118">
                    <div className="ignore482" />
                    <div className="ignore483" />
                  </div>
                  <img
                    className="icon-wrapper124"
                    alt=""
                    src="/iconwrapper-18@2x.png"
                  />
                </div>
              </div>
            </div>
            <div className="conf-acord9">
              <div className="polos2">
                <div className="configuracoes23">
                  <div className="wrapper54">
                    <div className="icon63">
                      <div className="width-change-size-here119">
                        <div className="ignore484" />
                        <div className="ignore485" />
                      </div>
                      <div className="icon-wrapper-h119">
                        <div className="height-change-size-here119">
                          <div className="ignore486" />
                          <div className="ignore487" />
                        </div>
                        <img
                          className="icon-wrapper125"
                          alt=""
                          src="/iconwrapper-33@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text207">
                      <div className="icon-manager">Polos</div>
                    </div>
                  </div>
                  <div className="arrow49">
                    <div className="width-change-size-here120">
                      <div className="ignore488" />
                      <div className="ignore489" />
                    </div>
                    <div className="icon-wrapper-h120">
                      <div className="height-change-size-here120">
                        <div className="ignore490" />
                        <div className="ignore491" />
                      </div>
                      <img
                        className="icon-wrapper126"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="form1">
                <div className="configuracoes24">
                  <div className="wrapper55">
                    <div className="icon64">
                      <div className="width-change-size-here121">
                        <div className="ignore492" />
                        <div className="ignore493" />
                      </div>
                      <div className="icon-wrapper-h121">
                        <div className="height-change-size-here121">
                          <div className="ignore494" />
                          <div className="ignore495" />
                        </div>
                        <img
                          className="icon-wrapper127"
                          alt=""
                          src="/iconwrapper-33@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text208">
                      <div className="text209">Formulários</div>
                    </div>
                  </div>
                  <div className="arrow50">
                    <div className="width-change-size-here122">
                      <div className="ignore496" />
                      <div className="ignore497" />
                    </div>
                    <div className="icon-wrapper-h122">
                      <div className="height-change-size-here122">
                        <div className="ignore498" />
                        <div className="ignore499" />
                      </div>
                      <img
                        className="icon-wrapper128"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="users1" onClick={onUsersContainerClick}>
                <div className="configuracoes25">
                  <div className="wrapper56">
                    <div className="icon65">
                      <div className="width-change-size-here123">
                        <div className="ignore500" />
                        <div className="ignore501" />
                      </div>
                      <div className="icon-wrapper-h123">
                        <div className="height-change-size-here123">
                          <div className="ignore502" />
                          <div className="ignore503" />
                        </div>
                        <img
                          className="icon-wrapper129"
                          alt=""
                          src="/iconwrapper-23@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text210">
                      <div className="text211">Utilizadores</div>
                    </div>
                  </div>
                  <div className="arrow51">
                    <div className="width-change-size-here124">
                      <div className="ignore504" />
                      <div className="ignore505" />
                    </div>
                    <div className="icon-wrapper-h124">
                      <div className="height-change-size-here124">
                        <div className="ignore506" />
                        <div className="ignore507" />
                      </div>
                      <img
                        className="icon-wrapper130"
                        alt=""
                        src="/iconwrapper-20@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="categorias1">
                <div className="configuracoes26">
                  <div className="wrapper57">
                    <div className="icon66">
                      <div className="width-change-size-here125">
                        <div className="ignore508" />
                        <div className="ignore509" />
                      </div>
                      <div className="icon-wrapper-h125">
                        <div className="height-change-size-here125">
                          <div className="ignore510" />
                          <div className="ignore511" />
                        </div>
                        <img
                          className="icon-wrapper131"
                          alt=""
                          src="/iconwrapper-33@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text212">
                      <div className="text213">Categorias</div>
                    </div>
                  </div>
                  <div className="arrow52">
                    <div className="width-change-size-here126">
                      <div className="ignore512" />
                      <div className="ignore513" />
                    </div>
                    <div className="icon-wrapper-h126">
                      <div className="height-change-size-here126">
                        <div className="ignore514" />
                        <div className="ignore515" />
                      </div>
                      <img
                        className="icon-wrapper132"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="subcategorias1">
                <div className="configuracoes27">
                  <div className="wrapper58">
                    <div className="icon67">
                      <div className="width-change-size-here127">
                        <div className="ignore516" />
                        <div className="ignore517" />
                      </div>
                      <div className="icon-wrapper-h127">
                        <div className="height-change-size-here127">
                          <div className="ignore518" />
                          <div className="ignore519" />
                        </div>
                        <img
                          className="icon-wrapper133"
                          loading="lazy"
                          alt=""
                          src="/iconwrapper-33@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text214">
                      <div className="text215">Subcategorias</div>
                    </div>
                  </div>
                  <div className="arrow53">
                    <div className="width-change-size-here128">
                      <div className="ignore520" />
                      <div className="ignore521" />
                    </div>
                    <div className="icon-wrapper-h128">
                      <div className="height-change-size-here128">
                        <div className="ignore522" />
                        <div className="ignore523" />
                      </div>
                      <img
                        className="icon-wrapper134"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="alertas1">
                <div className="configuracoes28">
                  <div className="wrapper59">
                    <div className="icon68">
                      <div className="width-change-size-here129">
                        <div className="ignore524" />
                        <div className="ignore525" />
                      </div>
                      <div className="icon-wrapper-h129">
                        <div className="height-change-size-here129">
                          <div className="ignore526" />
                          <div className="ignore527" />
                        </div>
                        <img
                          className="icon-wrapper135"
                          alt=""
                          src="/iconwrapper-33@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text216">
                      <div className="text217">Alertas</div>
                    </div>
                  </div>
                  <div className="arrow54">
                    <div className="width-change-size-here130">
                      <div className="ignore528" />
                      <div className="ignore529" />
                    </div>
                    <div className="icon-wrapper-h130">
                      <div className="height-change-size-here130">
                        <div className="ignore530" />
                        <div className="ignore531" />
                      </div>
                      <img
                        className="icon-wrapper136"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </div>
  );
};

export default FrameComponent3;
