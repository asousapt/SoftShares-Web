import "./FrameComponent4.css";

const FrameComponent4 = () => {
  return (
    <div className="admin-dashboard-parent">
      <h1 className="admin-dashboard3">Utilizadores</h1>
      <div className="segment-4-parent">
        <div className="segment-42">
          <div className="icon-container2">
            <div className="state-layer2">
              <img
                className="icon69"
                loading="lazy"
                alt=""
                src="/icon1@2x.png"
              />
              <div className="badge2">
                <div className="spacer6" />
              </div>
            </div>
          </div>
        </div>
        <img
          className="user-cicrle-duotone-icon2"
          loading="lazy"
          alt=""
          src="/user-cicrle-duotone@2x.png"
        />
      </div>
    </div>
  );
};

export default FrameComponent4;
