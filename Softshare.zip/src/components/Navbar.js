import "./Navbar.css";

const Navbar = () => {
  return (
    <div className="navbar2">
      <div className="atoms-colors-gray-32">
        <div className="atoms-colors-black2" />
      </div>
      <div className="button35">
        <img
          className="atoms-buttons-resources2"
          alt=""
          src="/atoms--buttons---resources--shapes--radius-bordered@2x.png"
        />
        <div className="atoms-buttons-labels-ac2">
          <div className="div25">Login</div>
        </div>
      </div>
      <div className="links3">
        <div className="div26">Contact</div>
        <div className="div27">Pricing</div>
        <div className="div28">Press</div>
        <div className="div29">Features</div>
        <div className="div30">How it works</div>
        <div className="div31">Home</div>
      </div>
      <img className="logo-icon2" alt="" src="/logo@2x.png" />
    </div>
  );
};

export default Navbar;
