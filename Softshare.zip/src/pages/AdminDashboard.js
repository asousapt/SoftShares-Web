import FrameComponent1 from "../components/FrameComponent1";
import FrameComponent from "../components/FrameComponent";
import Card from "../components/Card";
import "./AdminDashboard.css";

const AdminDashboard = () => {
  return (
    <div className="admin-dashboard2">
      <div className="desconectar3">
        <div className="wrapper29">
          <div className="icon42">
            <div className="width-change-size-here75">
              <div className="ignore308" />
              <div className="ignore309" />
            </div>
            <div className="icon-wrapper-h75">
              <div className="height-change-size-here75">
                <div className="ignore310" />
                <div className="ignore311" />
              </div>
              <img
                className="icon-wrapper81"
                alt=""
                src="/iconwrapper@2x.png"
              />
            </div>
          </div>
          <div className="text168">
            <div className="text169">Desconectar</div>
          </div>
        </div>
        <div className="arrow26">
          <div className="width-change-size-here76">
            <div className="ignore312" />
            <div className="ignore313" />
          </div>
          <div className="icon-wrapper-h76">
            <div className="height-change-size-here76">
              <div className="ignore314" />
              <div className="ignore315" />
            </div>
            <img
              className="icon-wrapper82"
              alt=""
              src="/iconwrapper-14@2x.png"
            />
          </div>
        </div>
      </div>
      <FrameComponent1 />
      <main className="instruction-processor">
        <section className="function-composer-parent">
          <FrameComponent />
          <div className="instruction-evaluator">
            <div className="value-receiver">
              <div className="value-receiver-child" />
              <header className="data-writer">
                <div className="metrics-21">
                  <div className="background1" />
                  <div className="title-frame">
                    <h2 className="title24">Registos por Aprovar</h2>
                  </div>
                  <div className="conditional-branch-parent">
                    <div className="conditional-branch">
                      <div className="loop-control">
                        <div className="variable-holder">
                          <div className="function-caller">
                            <img
                              className="img-box-light-icon3"
                              loading="lazy"
                              alt=""
                              src="/img-box-light1@2x.png"
                            />
                          </div>
                          <b className="error-handler">13</b>
                        </div>
                      </div>
                      <div className="pontos-de-interesse-wrapper">
                        <div className="pontos-de-interesse">
                          Pontos de Interesse
                        </div>
                      </div>
                    </div>
                    <div className="data-gatherer">
                      <div className="img-box-light-wrapper">
                        <img
                          className="img-box-light-icon4"
                          loading="lazy"
                          alt=""
                          src="/img-box-light-11@2x.png"
                        />
                      </div>
                      <div className="function-tree">
                        <div className="logic-gate">
                          <b className="input-source">35</b>
                        </div>
                        <div className="output-sink">
                          <div className="posts">Posts</div>
                        </div>
                      </div>
                    </div>
                    <div className="data-gatherer1">
                      <div className="img-box-light-container">
                        <img
                          className="img-box-light-icon5"
                          loading="lazy"
                          alt=""
                          src="/img-box-light-21@2x.png"
                        />
                      </div>
                      <div className="frame-parent5">
                        <div className="frame">
                          <b className="b1">9</b>
                        </div>
                        <div className="eventos-wrapper">
                          <div className="eventos">Eventos</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </header>
              <div className="variable-value">
                <div className="card-5-wrapper">
                  <Card prop="351" utilizadores="Utilizadores" />
                </div>
                <Card
                  prop="871"
                  utilizadores="Registos"
                  propAlignSelf="unset"
                  propPadding="var(--padding-78xl) var(--padding-48xl) var(--padding-83xl)"
                  propWidth="155px"
                  propMinWidth="61px"
                  propMarginLeft="-107px"
                  card5Width="unset"
                  card5MinWidth="unset"
                  frameDivAlignSelf="stretch"
                  divFlex="1"
                  divMinWidth="unset"
                />
                <div className="card-6">
                  <div className="bg" />
                  <div className="top-wrapper">
                    <div className="top">
                      <img
                        className="data-icon"
                        loading="lazy"
                        alt=""
                        src="/data-2.svg"
                      />
                      <div className="top-inner">
                        <div className="bg-light-grey-parent">
                          <div className="bg-light-grey" />
                          <div className="div15">871</div>
                        </div>
                      </div>
                      <div className="registos">Registos</div>
                    </div>
                  </div>
                  <div className="frame-parent6">
                    <div className="frame-parent7">
                      <div className="vector-parent">
                        <img
                          className="line-icon"
                          loading="lazy"
                          alt=""
                          src="/line-3.svg"
                        />
                        <div className="try-block">
                          <div className="pontos-de-interesse1">
                            Pontos de Interesse
                          </div>
                        </div>
                      </div>
                      <div className="wrapper30">
                        <div className="div16">244</div>
                      </div>
                    </div>
                    <div className="line-div" />
                    <div className="vector-group">
                      <img
                        className="frame-child6"
                        loading="lazy"
                        alt=""
                        src="/line-3-1.svg"
                      />
                      <div className="posts-frum-wrapper">
                        <div className="posts-frum">Posts Fórum</div>
                      </div>
                      <div className="wrapper31">
                        <div className="div17">348</div>
                      </div>
                    </div>
                    <div className="frame-child7" />
                    <div className="frame-wrapper3">
                      <div className="function-tree-leaf-parent">
                        <div className="function-tree-leaf">
                          <img
                            className="function-tree-leaf-child"
                            loading="lazy"
                            alt=""
                            src="/line-3-2.svg"
                          />
                          <div className="eventos1">Eventos</div>
                        </div>
                        <div className="function-tree-merge">279</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default AdminDashboard;
