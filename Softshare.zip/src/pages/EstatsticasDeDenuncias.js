import FrameComponent2 from "../components/FrameComponent2";
import Card from "../components/Card";
import "./EstatsticasDeDenuncias.css";

const EstatsticasDeDenuncias = () => {
  return (
    <div className="estatsticas-de-denuncias">
      <div className="desconectar">
        <div className="wrapper1">
          <div className="icon5">
            <div className="width-change-size-here2">
              <div className="ignore8" />
              <div className="ignore9" />
            </div>
            <div className="icon-wrapper-h2">
              <div className="height-change-size-here2">
                <div className="ignore10" />
                <div className="ignore11" />
              </div>
              <img className="icon-wrapper2" alt="" src="/iconwrapper@2x.png" />
            </div>
          </div>
          <div className="text6">
            <div className="text7">Desconectar</div>
          </div>
        </div>
        <div className="arrow">
          <div className="width-change-size-here3">
            <div className="ignore12" />
            <div className="ignore13" />
          </div>
          <div className="icon-wrapper-h3">
            <div className="height-change-size-here3">
              <div className="ignore14" />
              <div className="ignore15" />
            </div>
            <img
              className="icon-wrapper3"
              alt=""
              src="/iconwrapper-11@2x.png"
            />
          </div>
        </div>
      </div>
      <FrameComponent2 />
      <main className="accumulator">
        <section className="modifier">
          <div className="validator">
            <div className="calculator">
              <h1 className="admin-dashboard">Estatísticas de Denuncias</h1>
            </div>
            <div className="reducer">
              <div className="segment-4">
                <div className="icon-container">
                  <div className="state-layer">
                    <img
                      className="icon6"
                      loading="lazy"
                      alt=""
                      src="/icon@2x.png"
                    />
                    <div className="badge">
                      <div className="spacer" />
                    </div>
                  </div>
                </div>
              </div>
              <img
                className="user-cicrle-duotone-icon"
                loading="lazy"
                alt=""
                src="/user-cicrle-duotone@2x.png"
              />
            </div>
          </div>
          <div className="verifier">
            <div className="decoder">
              <div className="encryptor">
                <div className="compressor">
                  <div className="metrics-2">
                    <div className="background" />
                    <h2 className="title3">Estado das denuncias</h2>
                  </div>
                  <nav className="valores">
                    <div className="speaker-parent">
                      <div className="speaker">
                        <div className="sensor">
                          <div className="actuator">
                            <img
                              className="img-box-light-icon"
                              loading="lazy"
                              alt=""
                              src="/img-box-light@2x.png"
                            />
                          </div>
                          <b className="database">50</b>
                        </div>
                      </div>
                      <div className="network">
                        <div className="pendentes">Pendentes</div>
                      </div>
                    </div>
                    <div className="application">
                      <div className="img-box-light-parent">
                        <img
                          className="img-box-light-icon1"
                          loading="lazy"
                          alt=""
                          src="/img-box-light-1@2x.png"
                        />
                        <div className="client">
                          <div className="data-aggregator">
                            <b className="b">15</b>
                          </div>
                          <div className="aceites-wrapper">
                            <div className="aceites">Aceites</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="button-set-parent">
                      <div className="button-set">
                        <div className="dropdown-menu">
                          <img
                            className="img-box-light-icon2"
                            loading="lazy"
                            alt=""
                            src="/img-box-light-2@2x.png"
                          />
                          <div className="recusadas">Recusadas</div>
                        </div>
                      </div>
                      <b className="slider">10</b>
                    </div>
                  </nav>
                </div>
              </div>
              <div className="table-parent">
                <div className="users-mais-atividade">
                  <div className="mais-atividade">
                    Utilizador com mais denuncias
                  </div>
                  <img
                    className="divider-icon"
                    loading="lazy"
                    alt=""
                    src="/divider.svg"
                  />
                  <div className="informationbutton">
                    <img
                      className="image-icon"
                      loading="lazy"
                      alt=""
                      src="/image@2x.png"
                    />
                    <div className="name">
                      <div className="alexandre-marques">Alexandre Marques</div>
                      <div className="registo-criados">10 denuncias</div>
                      <div className="comentrios" />
                    </div>
                  </div>
                  <img
                    className="divider-icon1"
                    loading="lazy"
                    alt=""
                    src="/divider.svg"
                  />
                  <div className="informationbutton1">
                    <img
                      className="image-icon1"
                      loading="lazy"
                      alt=""
                      src="/image-1@2x.png"
                    />
                    <div className="name1">
                      <div className="antnio-mendes">António Mendes</div>
                      <div className="registos-criados">9 denuncias</div>
                      <div className="comentrios1" />
                    </div>
                  </div>
                  <img
                    className="divider-icon2"
                    loading="lazy"
                    alt=""
                    src="/divider.svg"
                  />
                  <div className="informationbutton2">
                    <img
                      className="image-icon2"
                      loading="lazy"
                      alt=""
                      src="/image-2@2x.png"
                    />
                    <div className="name2">
                      <div className="maria-silva">Maria Silva</div>
                      <div className="registos-criados1">6 denuncias</div>
                      <div className="comentrios2" />
                    </div>
                  </div>
                  <img
                    className="divider-icon3"
                    loading="lazy"
                    alt=""
                    src="/divider.svg"
                  />
                  <div className="informationbutton3">
                    <img
                      className="image-icon3"
                      loading="lazy"
                      alt=""
                      src="/image-3@2x.png"
                    />
                    <div className="name3">
                      <div className="cristina-almeida">Cristina Almeida</div>
                      <div className="registo-criados1">5 denuncias</div>
                      <div className="comentrios3" />
                    </div>
                  </div>
                  <img
                    className="divider-icon4"
                    loading="lazy"
                    alt=""
                    src="/divider.svg"
                  />
                  <div className="informationbutton4">
                    <img
                      className="image-icon4"
                      loading="lazy"
                      alt=""
                      src="/image-4@2x.png"
                    />
                    <div className="name4">
                      <div className="rodrigo-couto">Rodrigo Couto</div>
                      <div className="registo-criados2">4 denuncia</div>
                      <div className="comentrios4" />
                    </div>
                  </div>
                </div>
                <Card
                  prop="80"
                  utilizadores="Total"
                  propAlignSelf="unset"
                  propPadding="var(--padding-78xl) 85px var(--padding-83xl)"
                  propWidth="unset"
                  propMinWidth="35px"
                  propMarginLeft="-76.5px"
                  card5Width="343px"
                  card5MinWidth="343px"
                  frameDivAlignSelf="unset"
                  divFlex="unset"
                  divMinWidth="119px"
                />
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default EstatsticasDeDenuncias;
