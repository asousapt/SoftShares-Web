import { useCallback } from "react";
import FrameComponent3 from "../components/FrameComponent3";
import FrameComponent4 from "../components/FrameComponent4";
import "./ListaUtilizadores.css";

const ListaUtilizadores = () => {
  const onButtonContainerClick = useCallback(() => {
    // Please sync "Criar Utilizadores" to the project
  }, []);

  const onButtonContainer2Click = useCallback(() => {
    // Please sync "Detalhe Utilizadores" to the project
  }, []);

  return (
    <div className="lista-utilizadores">
      <div className="desconectar2">
        <div className="wrapper23">
          <div className="icon32">
            <div className="width-change-size-here54">
              <div className="ignore220" />
              <div className="ignore221" />
            </div>
            <div className="icon-wrapper-h54">
              <div className="height-change-size-here54">
                <div className="ignore222" />
                <div className="ignore223" />
              </div>
              <img
                className="icon-wrapper57"
                alt=""
                src="/iconwrapper@2x.png"
              />
            </div>
          </div>
          <div className="text97">
            <div className="text98">Desconectar</div>
          </div>
        </div>
        <div className="arrow21">
          <div className="width-change-size-here55">
            <div className="ignore224" />
            <div className="ignore225" />
          </div>
          <div className="icon-wrapper-h55">
            <div className="height-change-size-here55">
              <div className="ignore226" />
              <div className="ignore227" />
            </div>
            <img
              className="icon-wrapper58"
              alt=""
              src="/iconwrapper-14@2x.png"
            />
          </div>
        </div>
      </div>
      <FrameComponent3 />
      <main className="lista-utilizadores-inner">
        <section className="frame-section">
          <FrameComponent4 />
          <div className="table-body">
            <form className="table-footer">
              <div className="table-footer-child" />
              <div className="table-row">
                <div className="button18" onClick={onButtonContainerClick}>
                  <img
                    className="plus-circle-icon23"
                    alt=""
                    src="/pluscircle.svg"
                  />
                  <div className="table-thin-separator">
                    <div className="button-label15">Adicionar</div>
                  </div>
                  <img
                    className="plus-circle-icon24"
                    alt=""
                    src="/pluscircle.svg"
                  />
                </div>
                <div className="table-collapser">
                  <div className="table-sorting">
                    <div className="formdist1">
                      <div className="form-item1">
                        <div className="input4">
                          <div className="input-base2">
                            <div className="input5">
                              <div className="input-prefix2">
                                <div className="icon-wrapper59">
                                  <div className="width-change-size-here56">
                                    <div className="ignore228" />
                                    <div className="ignore229" />
                                  </div>
                                  <div className="icon-wrapper-h56">
                                    <div className="height-change-size-here56">
                                      <div className="ignore230" />
                                      <div className="ignore231" />
                                    </div>
                                    <img
                                      className="icon-wrapper60"
                                      alt=""
                                      src="/iconwrapper-311@2x.png"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="input6">Pesquisar</div>
                            </div>
                            <div className="spacer4">
                              <div className="ignore232" />
                              <div className="ignore233" />
                            </div>
                            <div className="input-suffix3">
                              <img
                                className="search-icon1"
                                loading="lazy"
                                alt=""
                                src="/search.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="data-aggregator1">
                      <div className="componentsdropdown-trigger-wi1">
                        <div className="dropdown-trigger1">
                          <div className="button19">
                            <div className="icon33">
                              <div className="width-change-size-here57">
                                <div className="ignore234" />
                                <div className="ignore235" />
                              </div>
                              <div className="icon-wrapper-h57">
                                <div className="height-change-size-here57">
                                  <div className="ignore236" />
                                  <div className="ignore237" />
                                </div>
                                <img
                                  className="icon-wrapper61"
                                  alt=""
                                  src="/iconwrapper-321@2x.png"
                                />
                              </div>
                            </div>
                            <div className="text99">
                              <div className="condition-checker">
                                Filtrar por Departamento
                              </div>
                            </div>
                            <div className="icon-22">
                              <div className="width-change-size-here58">
                                <div className="ignore238" />
                                <div className="ignore239" />
                              </div>
                              <div className="icon-wrapper-h58">
                                <div className="height-change-size-here58">
                                  <div className="ignore240" />
                                  <div className="ignore241" />
                                </div>
                                <img
                                  className="icon-wrapper62"
                                  alt=""
                                  src="/iconwrapper-331@2x.png"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="box2" />
                        <div className="zero-height2">
                          <div className="dropdown-menu2">
                            <div className="componentsdropdown-menu-item4">
                              <div className="wrapper24">
                                <div className="content6">
                                  <div className="icon34">
                                    <div className="width-change-size-here59">
                                      <div className="ignore242" />
                                      <div className="ignore243" />
                                    </div>
                                    <div className="icon-wrapper-h59">
                                      <div className="height-change-size-here59">
                                        <div className="ignore244" />
                                        <div className="ignore245" />
                                      </div>
                                      <img
                                        className="icon-wrapper63"
                                        alt=""
                                        src="/iconwrapper-34@2x.png"
                                      />
                                    </div>
                                  </div>
                                  <div className="text100">
                                    <div className="text101">Viseu</div>
                                  </div>
                                </div>
                                <div className="layout-blockshorizontal14">
                                  <div className="layout-blocksbase4">
                                    <div className="swap-label4">
                                      <span className="swap-label-txt4">
                                        <p className="p4">◇</p>
                                        <p className="swap4">Swap</p>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="arrow22">
                                <div className="width-change-size-here60">
                                  <div className="ignore246" />
                                  <div className="ignore247" />
                                </div>
                                <div className="icon-wrapper-h60">
                                  <div className="height-change-size-here60">
                                    <div className="ignore248" />
                                    <div className="ignore249" />
                                  </div>
                                  <img
                                    className="icon-wrapper64"
                                    alt=""
                                    src="/iconwrapper-35@2x.png"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="componentsdropdown-menu-item5">
                              <div className="wrapper25">
                                <div className="content7">
                                  <div className="icon35">
                                    <div className="width-change-size-here61">
                                      <div className="ignore250" />
                                      <div className="ignore251" />
                                    </div>
                                    <div className="icon-wrapper-h61">
                                      <div className="height-change-size-here61">
                                        <div className="ignore252" />
                                        <div className="ignore253" />
                                      </div>
                                      <img
                                        className="icon-wrapper65"
                                        alt=""
                                        src="/iconwrapper-34@2x.png"
                                      />
                                    </div>
                                  </div>
                                  <div className="text102">
                                    <div className="text103">Teste Região</div>
                                  </div>
                                </div>
                                <div className="layout-blockshorizontal15">
                                  <div className="layout-blocksbase5">
                                    <div className="swap-label5">
                                      <span className="swap-label-txt5">
                                        <p className="p5">◇</p>
                                        <p className="swap5">Swap</p>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="arrow23">
                                <div className="width-change-size-here62">
                                  <div className="ignore254" />
                                  <div className="ignore255" />
                                </div>
                                <div className="icon-wrapper-h62">
                                  <div className="height-change-size-here62">
                                    <div className="ignore256" />
                                    <div className="ignore257" />
                                  </div>
                                  <img
                                    className="icon-wrapper66"
                                    alt=""
                                    src="/iconwrapper-35@2x.png"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="componentsdropdown-menu-item6">
                              <div className="wrapper26">
                                <div className="content8">
                                  <div className="icon36">
                                    <div className="width-change-size-here63">
                                      <div className="ignore258" />
                                      <div className="ignore259" />
                                    </div>
                                    <div className="icon-wrapper-h63">
                                      <div className="height-change-size-here63">
                                        <div className="ignore260" />
                                        <div className="ignore261" />
                                      </div>
                                      <img
                                        className="icon-wrapper67"
                                        alt=""
                                        src="/iconwrapper-34@2x.png"
                                      />
                                    </div>
                                  </div>
                                  <div className="text104">
                                    <div className="text105">Coimbra</div>
                                  </div>
                                </div>
                                <div className="layout-blockshorizontal16">
                                  <div className="layout-blocksbase6">
                                    <div className="swap-label6">
                                      <span className="swap-label-txt6">
                                        <p className="p6">◇</p>
                                        <p className="swap6">Swap</p>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="arrow24">
                                <div className="width-change-size-here64">
                                  <div className="ignore262" />
                                  <div className="ignore263" />
                                </div>
                                <div className="icon-wrapper-h64">
                                  <div className="height-change-size-here64">
                                    <div className="ignore264" />
                                    <div className="ignore265" />
                                  </div>
                                  <img
                                    className="icon-wrapper68"
                                    alt=""
                                    src="/iconwrapper-35@2x.png"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="componentsdropdown-menu-item7">
                              <div className="wrapper27">
                                <div className="content9">
                                  <div className="icon37">
                                    <div className="width-change-size-here65">
                                      <div className="ignore266" />
                                      <div className="ignore267" />
                                    </div>
                                    <div className="icon-wrapper-h65">
                                      <div className="height-change-size-here65">
                                        <div className="ignore268" />
                                        <div className="ignore269" />
                                      </div>
                                      <img
                                        className="icon-wrapper69"
                                        alt=""
                                        src="/iconwrapper-34@2x.png"
                                      />
                                    </div>
                                  </div>
                                  <div className="text106">
                                    <div className="text107">Mostrar Todos</div>
                                  </div>
                                </div>
                                <div className="layout-blockshorizontal17">
                                  <div className="layout-blocksbase7">
                                    <div className="swap-label7">
                                      <span className="swap-label-txt7">
                                        <p className="p7">◇</p>
                                        <p className="swap7">Swap</p>
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                              <div className="arrow25">
                                <div className="width-change-size-here66">
                                  <div className="ignore270" />
                                  <div className="ignore271" />
                                </div>
                                <div className="icon-wrapper-h66">
                                  <div className="height-change-size-here66">
                                    <div className="ignore272" />
                                    <div className="ignore273" />
                                  </div>
                                  <img
                                    className="icon-wrapper70"
                                    alt=""
                                    src="/iconwrapper-35@2x.png"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="min-width1">
                              <div className="start1" />
                              <div className="end1" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="table-example-parent">
                <div className="table-example1">
                  <div className="text-cell-group">
                    <div className="text-cell56">
                      <div className="text108">ID</div>
                    </div>
                    <div className="text-cell57">
                      <div className="text109">1</div>
                    </div>
                    <div className="text-cell58">
                      <div className="text110">2</div>
                    </div>
                    <div className="text-cell59">
                      <div className="text111">3</div>
                    </div>
                    <div className="text-cell60">
                      <div className="text112">4</div>
                    </div>
                    <div className="text-cell61">
                      <div className="text113">5</div>
                    </div>
                    <div className="text-cell62">
                      <div className="text114">6</div>
                    </div>
                    <div className="text-cell63">
                      <div className="text115">7</div>
                    </div>
                  </div>
                  <div className="text-cell-container">
                    <div className="text-cell64">
                      <div className="text116">Nome</div>
                    </div>
                    <div className="text-cell65">
                      <div className="text117">Antonio Sousa</div>
                    </div>
                    <div className="text-cell66">
                      <div className="text118">Ronald Richards</div>
                    </div>
                    <div className="text-cell67">
                      <div className="text119">Jerome Bell</div>
                    </div>
                    <div className="text-cell68">
                      <div className="text120">Robert Fox</div>
                    </div>
                    <div className="text-cell69">
                      <div className="text121">Bessie Cooper</div>
                    </div>
                    <div className="text-cell70">
                      <div className="text122">Kathryn Murphy</div>
                    </div>
                    <div className="text-cell71">
                      <div className="text123">Courtney Henry</div>
                    </div>
                  </div>
                  <div className="text-cell-parent1">
                    <div className="text-cell72">
                      <div className="text124">Tipo</div>
                    </div>
                    <div className="text-cell73">
                      <div className="text125">Admin</div>
                    </div>
                    <div className="text-cell74">
                      <div className="text126">Utilizador</div>
                    </div>
                    <div className="text-cell75">
                      <div className="text127">Admin</div>
                    </div>
                    <div className="text-cell76">
                      <div className="text128">Utilizador</div>
                    </div>
                    <div className="text-cell77">
                      <div className="text129">Utilizador</div>
                    </div>
                    <div className="text-cell78">
                      <div className="text130">Utilizador</div>
                    </div>
                    <div className="text-cell79">
                      <div className="text131">Utilizador</div>
                    </div>
                  </div>
                  <div className="text-cell-parent2">
                    <div className="text-cell80">
                      <div className="text132">Data de criação</div>
                    </div>
                    <div className="text-cell81">
                      <div className="text133">02/07/1971</div>
                    </div>
                    <div className="text-cell82">
                      <div className="text134">28/03/1968</div>
                    </div>
                    <div className="text-cell83">
                      <div className="text135">12/08/1994</div>
                    </div>
                    <div className="text-cell84">
                      <div className="text136">02/01/1980</div>
                    </div>
                    <div className="text-cell85">
                      <div className="text137">27/11/1987</div>
                    </div>
                    <div className="text-cell86">
                      <div className="text138">22/08/1969</div>
                    </div>
                    <div className="text-cell87">
                      <div className="text139">20/06/1988</div>
                    </div>
                  </div>
                  <div className="text-cell-parent3">
                    <div className="text-cell88">
                      <div className="text140">Departamento</div>
                    </div>
                    <div className="text-cell89">
                      <div className="text141">Informática</div>
                    </div>
                    <div className="text-cell90">
                      <div className="text142">Informática</div>
                    </div>
                    <div className="text-cell91">
                      <div className="text143">Marketing</div>
                    </div>
                    <div className="text-cell92">
                      <div className="text144">Recursos Humanos</div>
                    </div>
                    <div className="text-cell93">
                      <div className="text145">Vendas</div>
                    </div>
                    <div className="text-cell94">
                      <div className="text146">Infraestrutura</div>
                    </div>
                    <div className="text-cell95">
                      <div className="text147">Recursos Humanos</div>
                    </div>
                  </div>
                  <div className="text-cell-parent4">
                    <div className="text-cell96">
                      <div className="text148">Função</div>
                    </div>
                    <div className="text-cell97">
                      <div className="text149">Programador</div>
                    </div>
                    <div className="text-cell98">
                      <div className="text150">Gestor de Projetos</div>
                    </div>
                    <div className="text-cell99">
                      <div className="text151">Marketing</div>
                    </div>
                    <div className="text-cell100">
                      <div className="text152">Recurso Humanos</div>
                    </div>
                    <div className="text-cell101">
                      <div className="text153">Advogado</div>
                    </div>
                    <div className="text-cell102">
                      <div className="text154">Admin de Redes</div>
                    </div>
                    <div className="text-cell103">
                      <div className="text155">Gestor de Base de dados</div>
                    </div>
                  </div>
                  <div className="text-cell-parent5">
                    <div className="text-cell104">
                      <div className="text156">Status</div>
                    </div>
                    <div className="text-cell105">
                      <div className="button20">
                        <img
                          className="plus-circle-icon25"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                        <div className="button-label16">Active</div>
                        <img
                          className="plus-circle-icon26"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell106">
                      <div className="button21">
                        <img
                          className="plus-circle-icon27"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                        <div className="button-label17">Inactive</div>
                        <img
                          className="plus-circle-icon28"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell107">
                      <div className="button22">
                        <img
                          className="plus-circle-icon29"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                        <div className="button-label18">Active</div>
                        <img
                          className="plus-circle-icon30"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell108">
                      <div className="button23">
                        <img
                          className="plus-circle-icon31"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                        <div className="button-label19">Active</div>
                        <img
                          className="plus-circle-icon32"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell109">
                      <div className="button24">
                        <img
                          className="plus-circle-icon33"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                        <div className="button-label20">Inactive</div>
                        <img
                          className="plus-circle-icon34"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell110">
                      <div className="button25">
                        <img
                          className="plus-circle-icon35"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                        <div className="button-label21">Inactive</div>
                        <img
                          className="plus-circle-icon36"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell111">
                      <div className="button26">
                        <img
                          className="plus-circle-icon37"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                        <div className="button-label22">Active</div>
                        <img
                          className="plus-circle-icon38"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="text-cell-parent6">
                    <div className="text-cell112">
                      <div className="text157">Status</div>
                    </div>
                    <div className="text-cell113">
                      <div
                        className="button27"
                        onClick={onButtonContainer2Click}
                      >
                        <img
                          className="edit-icon7"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label23" />
                        <img
                          className="plus-circle-icon39"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell114">
                      <div className="button28">
                        <img
                          className="edit-icon8"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label24" />
                        <img
                          className="plus-circle-icon40"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell115">
                      <div className="button29">
                        <img
                          className="edit-icon9"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label25" />
                        <img
                          className="plus-circle-icon41"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell116">
                      <div className="button30">
                        <img
                          className="edit-icon10"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label26" />
                        <img
                          className="plus-circle-icon42"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell117">
                      <div className="button31">
                        <img
                          className="edit-icon11"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label27" />
                        <img
                          className="plus-circle-icon43"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell118">
                      <div className="button32">
                        <img
                          className="edit-icon12"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label28" />
                        <img
                          className="plus-circle-icon44"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell119">
                      <div className="button33">
                        <img
                          className="edit-icon13"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label29" />
                        <img
                          className="plus-circle-icon45"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="rectangle-parent1">
                  <div className="frame-child5" />
                  <div className="pagination1">
                    <div className="content10">
                      <div className="texttext9">
                        <div className="text158">Total 85 items</div>
                      </div>
                      <div className="page-items1">
                        <div className="componentspagination-prev1">
                          <div className="icon38">
                            <div className="width-change-size-here67">
                              <div className="ignore274" />
                              <div className="ignore275" />
                            </div>
                            <div className="icon-wrapper-h67">
                              <div className="height-change-size-here67">
                                <div className="ignore276" />
                                <div className="ignore277" />
                              </div>
                              <img
                                className="icon-wrapper71"
                                loading="lazy"
                                alt=""
                                src="/iconwrapper-42@2x.png"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="componentspagination-item7">
                          <div className="texttext10">
                            <div className="text159">1</div>
                          </div>
                        </div>
                        <div className="componentspagination-item-ell2">
                          <div className="icon39">
                            <div className="width-change-size-here68">
                              <div className="ignore278" />
                              <div className="ignore279" />
                            </div>
                            <div className="icon-wrapper-h68">
                              <div className="height-change-size-here68">
                                <div className="ignore280" />
                                <div className="ignore281" />
                              </div>
                              <img
                                className="icon-wrapper72"
                                loading="lazy"
                                alt=""
                                src="/iconwrapper-43@2x.png"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="componentspagination-item8">
                          <div className="texttext11">
                            <div className="text160">4</div>
                          </div>
                        </div>
                        <div className="componentspagination-item9">
                          <div className="texttext12">
                            <div className="text161">5</div>
                          </div>
                        </div>
                        <div className="componentspagination-item10">
                          <div className="texttext13">
                            <div className="text162">6</div>
                          </div>
                        </div>
                        <div className="componentspagination-item11">
                          <div className="texttext14">
                            <div className="text163">7</div>
                          </div>
                        </div>
                        <div className="componentspagination-item12">
                          <div className="texttext15">
                            <div className="text164">8</div>
                          </div>
                        </div>
                        <div className="componentspagination-item-ell3">
                          <div className="icon40">
                            <div className="width-change-size-here69">
                              <div className="ignore282" />
                              <div className="ignore283" />
                            </div>
                            <div className="icon-wrapper-h69">
                              <div className="height-change-size-here69">
                                <div className="ignore284" />
                                <div className="ignore285" />
                              </div>
                              <img
                                className="icon-wrapper73"
                                loading="lazy"
                                alt=""
                                src="/iconwrapper-43@2x.png"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="componentspagination-item13">
                          <div className="texttext16">
                            <div className="text165">20</div>
                          </div>
                        </div>
                        <div className="componentspagination-next1">
                          <div className="icon41">
                            <div className="width-change-size-here70">
                              <div className="ignore286" />
                              <div className="ignore287" />
                            </div>
                            <div className="icon-wrapper-h70">
                              <div className="height-change-size-here70">
                                <div className="ignore288" />
                                <div className="ignore289" />
                              </div>
                              <img
                                className="icon-wrapper74"
                                loading="lazy"
                                alt=""
                                src="/iconwrapper-45@2x.png"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="pagination-options1">
                      <div className="select1">
                        <div className="wrapper28">
                          <div className="selection-item1">
                            <div className="placeholder3">
                              <div className="text166">10 / page</div>
                            </div>
                          </div>
                          <div className="input-suffix4">
                            <div className="icon-wrapper75">
                              <div className="width-change-size-here71">
                                <div className="ignore290" />
                                <div className="ignore291" />
                              </div>
                              <div className="icon-wrapper-h71">
                                <div className="height-change-size-here71">
                                  <div className="ignore292" />
                                  <div className="ignore293" />
                                </div>
                                <img
                                  className="icon-wrapper76"
                                  alt=""
                                  src="/iconwrapper-461@2x.png"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="icon-down1">
                            <div className="width-change-size-here72">
                              <div className="ignore294" />
                              <div className="ignore295" />
                            </div>
                            <div className="icon-wrapper-h72">
                              <div className="height-change-size-here72">
                                <div className="ignore296" />
                                <div className="ignore297" />
                              </div>
                              <img
                                className="icon-select-down1"
                                alt=""
                                src="/-iconselectdown.svg"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="box3" />
                        <div className="zero-height3">
                          <div className="select-options1">
                            <div className="componentsselect-optionsingl10">
                              <div className="title14">Option 01</div>
                            </div>
                            <div className="componentsselect-optionsingl11">
                              <div className="title15">Option 02</div>
                            </div>
                            <div className="componentsselect-optionsingl12">
                              <div className="title16">Option 03</div>
                            </div>
                            <div className="componentsselect-optionsingl13">
                              <div className="title17">Option 04</div>
                            </div>
                            <div className="componentsselect-optionsingl14">
                              <div className="title18">Option 05</div>
                            </div>
                            <div className="componentsselect-optionsingl15">
                              <div className="title19">Option 06</div>
                            </div>
                            <div className="componentsselect-optionsingl16">
                              <div className="title20">Option 07</div>
                            </div>
                            <div className="componentsselect-optionsingl17">
                              <div className="title21">Option 08</div>
                            </div>
                            <div className="componentsselect-optionsingl18">
                              <div className="title22">Option 09</div>
                            </div>
                            <div className="componentsselect-optionsingl19">
                              <div className="title23">Option 10</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="quick-jumper1">
                        <div className="texttext17">
                          <div className="text167">Go to</div>
                        </div>
                        <div className="input7">
                          <div className="input-base3">
                            <div className="placeholder4">
                              <div className="input-prefix3">
                                <div className="icon-wrapper77">
                                  <div className="width-change-size-here73">
                                    <div className="ignore298" />
                                    <div className="ignore299" />
                                  </div>
                                  <div className="icon-wrapper-h73">
                                    <div className="height-change-size-here73">
                                      <div className="ignore300" />
                                      <div className="ignore301" />
                                    </div>
                                    <img
                                      className="icon-wrapper78"
                                      alt=""
                                      src="/iconwrapper-471@2x.png"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="placeholder5" />
                            </div>
                            <div className="spacer5">
                              <div className="ignore302" />
                              <div className="ignore303" />
                            </div>
                            <div className="input-suffix5">
                              <div className="icon-wrapper79">
                                <div className="width-change-size-here74">
                                  <div className="ignore304" />
                                  <div className="ignore305" />
                                </div>
                                <div className="icon-wrapper-h74">
                                  <div className="height-change-size-here74">
                                    <div className="ignore306" />
                                    <div className="ignore307" />
                                  </div>
                                  <img
                                    className="icon-wrapper80"
                                    alt=""
                                    src="/iconwrapper-461@2x.png"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        </section>
      </main>
    </div>
  );
};

export default ListaUtilizadores;
