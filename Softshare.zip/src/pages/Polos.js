import { useCallback } from "react";
import Navbar from "../components/Navbar";
import { useNavigate } from "react-router-dom";
import "./Polos.css";

const Polos = () => {
  const navigate = useNavigate();

  const onPolosContainerClick = useCallback(() => {
    navigate("/polos");
  }, [navigate]);

  const onButtonContainerClick = useCallback(() => {
    // Please sync "Form Nova Polo" to the project
  }, []);

  const onButtonContainer2Click = useCallback(() => {
    // Please sync " Form Editar Região" to the project
  }, []);

  return (
    <div className="polos">
      <div className="desconectar1">
        <div className="wrapper2">
          <div className="icon7">
            <div className="width-change-size-here4">
              <div className="ignore16" />
              <div className="ignore17" />
            </div>
            <div className="icon-wrapper-h4">
              <div className="height-change-size-here4">
                <div className="ignore18" />
                <div className="ignore19" />
              </div>
              <img className="icon-wrapper4" alt="" src="/iconwrapper@2x.png" />
            </div>
          </div>
          <div className="text8">
            <div className="text9">Desconectar</div>
          </div>
        </div>
        <div className="arrow1">
          <div className="width-change-size-here5">
            <div className="ignore20" />
            <div className="ignore21" />
          </div>
          <div className="icon-wrapper-h5">
            <div className="height-change-size-here5">
              <div className="ignore22" />
              <div className="ignore23" />
            </div>
            <img
              className="icon-wrapper5"
              alt=""
              src="/iconwrapper-13@2x.png"
            />
          </div>
        </div>
      </div>
      <div className="input-filter">
        <div className="navbar-11">
          <Navbar />
        </div>
        <div className="frame-parent4">
          <div className="subtree-parent">
            <div className="subtree">
              <h2 className="viseu">Viseu</h2>
            </div>
            <h1 className="bem-vindo">Bem-vindo</h1>
          </div>
          <div className="user">@user</div>
        </div>
        <div className="input-filter-inner">
          <div className="dashboard-parent">
            <div className="dashboard">
              <div className="configuracoes">
                <div className="wrapper3">
                  <div className="text10">
                    <div className="text11">Dashboard</div>
                  </div>
                </div>
                <div className="arrow2">
                  <div className="width-change-size-here6">
                    <div className="ignore24" />
                    <div className="ignore25" />
                  </div>
                  <div className="icon-wrapper-h6">
                    <div className="height-change-size-here6">
                      <div className="ignore26" />
                      <div className="ignore27" />
                    </div>
                    <img
                      className="icon-wrapper6"
                      alt=""
                      src="/iconwrapper-21@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="conf-acord">
                <div className="aprovacoes">
                  <div className="wrapper4">
                    <div className="icon8">
                      <div className="width-change-size-here7">
                        <div className="ignore28" />
                        <div className="ignore29" />
                      </div>
                      <div className="icon-wrapper-h7">
                        <div className="height-change-size-here7">
                          <div className="ignore30" />
                          <div className="ignore31" />
                        </div>
                        <img
                          className="icon-wrapper7"
                          alt=""
                          src="/iconwrapper-31@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text12">
                      <div className="text13">Formulários</div>
                    </div>
                  </div>
                  <div className="arrow3">
                    <div className="width-change-size-here8">
                      <div className="ignore32" />
                      <div className="ignore33" />
                    </div>
                    <div className="icon-wrapper-h8">
                      <div className="height-change-size-here8">
                        <div className="ignore34" />
                        <div className="ignore35" />
                      </div>
                      <img
                        className="icon-wrapper8"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
                <div className="permisses">
                  <div className="wrapper5">
                    <div className="icon9">
                      <div className="width-change-size-here9">
                        <div className="ignore36" />
                        <div className="ignore37" />
                      </div>
                      <div className="icon-wrapper-h9">
                        <div className="height-change-size-here9">
                          <div className="ignore38" />
                          <div className="ignore39" />
                        </div>
                        <img
                          className="icon-wrapper9"
                          alt=""
                          src="/iconwrapper-31@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text14">
                      <div className="text15">Utilizadores</div>
                    </div>
                  </div>
                  <div className="arrow4">
                    <div className="width-change-size-here10">
                      <div className="ignore40" />
                      <div className="ignore41" />
                    </div>
                    <div className="icon-wrapper-h10">
                      <div className="height-change-size-here10">
                        <div className="ignore42" />
                        <div className="ignore43" />
                      </div>
                      <img
                        className="icon-wrapper10"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="estatisticas">
              <div className="configuracoes1">
                <div className="wrapper6">
                  <div className="icon10">
                    <div className="width-change-size-here11">
                      <div className="ignore44" />
                      <div className="ignore45" />
                    </div>
                    <div className="icon-wrapper-h11">
                      <div className="height-change-size-here11">
                        <div className="ignore46" />
                        <div className="ignore47" />
                      </div>
                      <img
                        className="icon-wrapper11"
                        alt=""
                        src="/iconwrapper-31@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text16">
                    <div className="text17">Estatísticas</div>
                  </div>
                </div>
                <div className="arrow5">
                  <div className="width-change-size-here12">
                    <div className="ignore48" />
                    <div className="ignore49" />
                  </div>
                  <div className="icon-wrapper-h12">
                    <div className="height-change-size-here12">
                      <div className="ignore50" />
                      <div className="ignore51" />
                    </div>
                    <img
                      className="icon-wrapper12"
                      alt=""
                      src="/iconwrapper-21@2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="listagens">
              <div className="configuracoes2">
                <div className="wrapper7">
                  <div className="icon11">
                    <div className="width-change-size-here13">
                      <div className="ignore52" />
                      <div className="ignore53" />
                    </div>
                    <div className="icon-wrapper-h13">
                      <div className="height-change-size-here13">
                        <div className="ignore54" />
                        <div className="ignore55" />
                      </div>
                      <img
                        className="icon-wrapper13"
                        alt=""
                        src="/iconwrapper-31@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text18">
                    <div className="text19">Listagem</div>
                  </div>
                </div>
                <div className="arrow6">
                  <div className="width-change-size-here14">
                    <div className="ignore56" />
                    <div className="ignore57" />
                  </div>
                  <div className="icon-wrapper-h14">
                    <div className="height-change-size-here14">
                      <div className="ignore58" />
                      <div className="ignore59" />
                    </div>
                    <img
                      className="icon-wrapper14"
                      alt=""
                      src="/iconwrapper-21@2x.png"
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="moderacao">
              <div className="configuracoes3">
                <div className="wrapper8">
                  <div className="icon12">
                    <div className="width-change-size-here15">
                      <div className="ignore60" />
                      <div className="ignore61" />
                    </div>
                    <div className="icon-wrapper-h15">
                      <div className="height-change-size-here15">
                        <div className="ignore62" />
                        <div className="ignore63" />
                      </div>
                      <img
                        className="icon-wrapper15"
                        loading="lazy"
                        alt=""
                        src="/iconwrapper-31@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text20">
                    <div className="text21">Moderação</div>
                  </div>
                </div>
                <div className="arrow7">
                  <div className="width-change-size-here16">
                    <div className="ignore64" />
                    <div className="ignore65" />
                  </div>
                  <div className="icon-wrapper-h16">
                    <div className="height-change-size-here16">
                      <div className="ignore66" />
                      <div className="ignore67" />
                    </div>
                    <img
                      className="icon-wrapper16"
                      alt=""
                      src="/iconwrapper-21@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="conf-acord1">
                <div className="aprovacoes1">
                  <div className="wrapper9">
                    <div className="icon13">
                      <div className="width-change-size-here17">
                        <div className="ignore68" />
                        <div className="ignore69" />
                      </div>
                      <div className="icon-wrapper-h17">
                        <div className="height-change-size-here17">
                          <div className="ignore70" />
                          <div className="ignore71" />
                        </div>
                        <img
                          className="icon-wrapper17"
                          alt=""
                          src="/iconwrapper-31@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text22">
                      <div className="text23">Formulários</div>
                    </div>
                  </div>
                  <div className="arrow8">
                    <div className="width-change-size-here18">
                      <div className="ignore72" />
                      <div className="ignore73" />
                    </div>
                    <div className="icon-wrapper-h18">
                      <div className="height-change-size-here18">
                        <div className="ignore74" />
                        <div className="ignore75" />
                      </div>
                      <img
                        className="icon-wrapper18"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
                <div className="permisses1">
                  <div className="wrapper10">
                    <div className="icon14">
                      <div className="width-change-size-here19">
                        <div className="ignore76" />
                        <div className="ignore77" />
                      </div>
                      <div className="icon-wrapper-h19">
                        <div className="height-change-size-here19">
                          <div className="ignore78" />
                          <div className="ignore79" />
                        </div>
                        <img
                          className="icon-wrapper19"
                          alt=""
                          src="/iconwrapper-31@2x.png"
                        />
                      </div>
                    </div>
                    <div className="text24">
                      <div className="text25">Utilizadores</div>
                    </div>
                  </div>
                  <div className="arrow9">
                    <div className="width-change-size-here20">
                      <div className="ignore80" />
                      <div className="ignore81" />
                    </div>
                    <div className="icon-wrapper-h20">
                      <div className="height-change-size-here20">
                        <div className="ignore82" />
                        <div className="ignore83" />
                      </div>
                      <img
                        className="icon-wrapper20"
                        alt=""
                        src="/iconwrapper-21@2x.png"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="configuraes">
              <div className="configuracoes4">
                <div className="wrapper11">
                  <div className="icon15">
                    <div className="width-change-size-here21">
                      <div className="ignore84" />
                      <div className="ignore85" />
                    </div>
                    <div className="icon-wrapper-h21">
                      <div className="height-change-size-here21">
                        <div className="ignore86" />
                        <div className="ignore87" />
                      </div>
                      <img
                        className="icon-wrapper21"
                        loading="lazy"
                        alt=""
                        src="/iconwrapper-17@2x.png"
                      />
                    </div>
                  </div>
                  <div className="text26">
                    <div className="text27">Configuração</div>
                  </div>
                </div>
                <div className="arrow10">
                  <div className="width-change-size-here22">
                    <div className="ignore88" />
                    <div className="ignore89" />
                  </div>
                  <div className="icon-wrapper-h22">
                    <div className="height-change-size-here22">
                      <div className="ignore90" />
                      <div className="ignore91" />
                    </div>
                    <img
                      className="icon-wrapper22"
                      alt=""
                      src="/iconwrapper-18@2x.png"
                    />
                  </div>
                </div>
              </div>
              <div className="conf-acord2">
                <div className="polos1" onClick={onPolosContainerClick}>
                  <div className="configuracoes5">
                    <div className="wrapper12">
                      <div className="icon16">
                        <div className="width-change-size-here23">
                          <div className="ignore92" />
                          <div className="ignore93" />
                        </div>
                        <div className="icon-wrapper-h23">
                          <div className="height-change-size-here23">
                            <div className="ignore94" />
                            <div className="ignore95" />
                          </div>
                          <img
                            className="icon-wrapper23"
                            alt=""
                            src="/iconwrapper-19@2x.png"
                          />
                        </div>
                      </div>
                      <div className="text28">
                        <div className="for-loop">Polos</div>
                      </div>
                    </div>
                    <div className="arrow11">
                      <div className="width-change-size-here24">
                        <div className="ignore96" />
                        <div className="ignore97" />
                      </div>
                      <div className="icon-wrapper-h24">
                        <div className="height-change-size-here24">
                          <div className="ignore98" />
                          <div className="ignore99" />
                        </div>
                        <img
                          className="icon-wrapper24"
                          alt=""
                          src="/iconwrapper-20@2x.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="form">
                  <div className="configuracoes6">
                    <div className="wrapper13">
                      <div className="icon17">
                        <div className="width-change-size-here25">
                          <div className="ignore100" />
                          <div className="ignore101" />
                        </div>
                        <div className="icon-wrapper-h25">
                          <div className="height-change-size-here25">
                            <div className="ignore102" />
                            <div className="ignore103" />
                          </div>
                          <img
                            className="icon-wrapper25"
                            alt=""
                            src="/iconwrapper-31@2x.png"
                          />
                        </div>
                      </div>
                      <div className="text29">
                        <div className="text30">Formulários</div>
                      </div>
                    </div>
                    <div className="arrow12">
                      <div className="width-change-size-here26">
                        <div className="ignore104" />
                        <div className="ignore105" />
                      </div>
                      <div className="icon-wrapper-h26">
                        <div className="height-change-size-here26">
                          <div className="ignore106" />
                          <div className="ignore107" />
                        </div>
                        <img
                          className="icon-wrapper26"
                          alt=""
                          src="/iconwrapper-21@2x.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="users">
                  <div className="configuracoes7">
                    <div className="wrapper14">
                      <div className="icon18">
                        <div className="width-change-size-here27">
                          <div className="ignore108" />
                          <div className="ignore109" />
                        </div>
                        <div className="icon-wrapper-h27">
                          <div className="height-change-size-here27">
                            <div className="ignore110" />
                            <div className="ignore111" />
                          </div>
                          <img
                            className="icon-wrapper27"
                            alt=""
                            src="/iconwrapper-31@2x.png"
                          />
                        </div>
                      </div>
                      <div className="text31">
                        <div className="text32">Utilizadores</div>
                      </div>
                    </div>
                    <div className="arrow13">
                      <div className="width-change-size-here28">
                        <div className="ignore112" />
                        <div className="ignore113" />
                      </div>
                      <div className="icon-wrapper-h28">
                        <div className="height-change-size-here28">
                          <div className="ignore114" />
                          <div className="ignore115" />
                        </div>
                        <img
                          className="icon-wrapper28"
                          alt=""
                          src="/iconwrapper-21@2x.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="categorias">
                  <div className="configuracoes8">
                    <div className="wrapper15">
                      <div className="icon19">
                        <div className="width-change-size-here29">
                          <div className="ignore116" />
                          <div className="ignore117" />
                        </div>
                        <div className="icon-wrapper-h29">
                          <div className="height-change-size-here29">
                            <div className="ignore118" />
                            <div className="ignore119" />
                          </div>
                          <img
                            className="icon-wrapper29"
                            alt=""
                            src="/iconwrapper-31@2x.png"
                          />
                        </div>
                      </div>
                      <div className="text33">
                        <div className="text34">Categorias</div>
                      </div>
                    </div>
                    <div className="arrow14">
                      <div className="width-change-size-here30">
                        <div className="ignore120" />
                        <div className="ignore121" />
                      </div>
                      <div className="icon-wrapper-h30">
                        <div className="height-change-size-here30">
                          <div className="ignore122" />
                          <div className="ignore123" />
                        </div>
                        <img
                          className="icon-wrapper30"
                          alt=""
                          src="/iconwrapper-21@2x.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="subcategorias">
                  <div className="configuracoes9">
                    <div className="wrapper16">
                      <div className="icon20">
                        <div className="width-change-size-here31">
                          <div className="ignore124" />
                          <div className="ignore125" />
                        </div>
                        <div className="icon-wrapper-h31">
                          <div className="height-change-size-here31">
                            <div className="ignore126" />
                            <div className="ignore127" />
                          </div>
                          <img
                            className="icon-wrapper31"
                            loading="lazy"
                            alt=""
                            src="/iconwrapper-31@2x.png"
                          />
                        </div>
                      </div>
                      <div className="text35">
                        <div className="text36">Subcategorias</div>
                      </div>
                    </div>
                    <div className="arrow15">
                      <div className="width-change-size-here32">
                        <div className="ignore128" />
                        <div className="ignore129" />
                      </div>
                      <div className="icon-wrapper-h32">
                        <div className="height-change-size-here32">
                          <div className="ignore130" />
                          <div className="ignore131" />
                        </div>
                        <img
                          className="icon-wrapper32"
                          alt=""
                          src="/iconwrapper-21@2x.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <div className="alertas">
                  <div className="configuracoes10">
                    <div className="wrapper17">
                      <div className="icon21">
                        <div className="width-change-size-here33">
                          <div className="ignore132" />
                          <div className="ignore133" />
                        </div>
                        <div className="icon-wrapper-h33">
                          <div className="height-change-size-here33">
                            <div className="ignore134" />
                            <div className="ignore135" />
                          </div>
                          <img
                            className="icon-wrapper33"
                            alt=""
                            src="/iconwrapper-31@2x.png"
                          />
                        </div>
                      </div>
                      <div className="text37">
                        <div className="text38">Alertas</div>
                      </div>
                    </div>
                    <div className="arrow16">
                      <div className="width-change-size-here34">
                        <div className="ignore136" />
                        <div className="ignore137" />
                      </div>
                      <div className="icon-wrapper-h34">
                        <div className="height-change-size-here34">
                          <div className="ignore138" />
                          <div className="ignore139" />
                        </div>
                        <img
                          className="icon-wrapper34"
                          alt=""
                          src="/iconwrapper-21@2x.png"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <main className="data-filter">
        <section className="data-comparer">
          <div className="data-combiner">
            <div className="data-mapper">
              <h1 className="admin-dashboard1">Polos</h1>
            </div>
            <div className="data-merger">
              <div className="segment-41">
                <div className="icon-container1">
                  <div className="state-layer1">
                    <img
                      className="icon22"
                      loading="lazy"
                      alt=""
                      src="/icon1@2x.png"
                    />
                    <div className="badge1">
                      <div className="spacer1" />
                    </div>
                  </div>
                </div>
              </div>
              <img
                className="user-cicrle-duotone-icon1"
                loading="lazy"
                alt=""
                src="/user-cicrle-duotone@2x.png"
              />
            </div>
          </div>
          <div className="data-summarizer">
            <div className="data-extractor">
              <div className="data-extractor-child" />
              <div className="data-enhancer">
                <nav className="data-reducer">
                  <div className="data-updater">
                    <div className="button2" onClick={onButtonContainerClick}>
                      <img
                        className="plus-circle-icon"
                        alt=""
                        src="/pluscircle.svg"
                      />
                      <div className="data-validator">
                        <div className="button-label">Adicionar</div>
                      </div>
                      <img
                        className="plus-circle-icon1"
                        alt=""
                        src="/pluscircle.svg"
                      />
                    </div>
                  </div>
                  <div className="data-mapper1">
                    <div className="formdist">
                      <div className="form-item">
                        <div className="input">
                          <div className="input-base">
                            <div className="input1">
                              <div className="input-prefix">
                                <div className="icon-wrapper35">
                                  <div className="width-change-size-here35">
                                    <div className="ignore140" />
                                    <div className="ignore141" />
                                  </div>
                                  <div className="icon-wrapper-h35">
                                    <div className="height-change-size-here35">
                                      <div className="ignore142" />
                                      <div className="ignore143" />
                                    </div>
                                    <img
                                      className="icon-wrapper36"
                                      alt=""
                                      src="/iconwrapper-311@2x.png"
                                    />
                                  </div>
                                </div>
                              </div>
                              <div className="input2">Pesquisar</div>
                            </div>
                            <div className="spacer2">
                              <div className="ignore144" />
                              <div className="ignore145" />
                            </div>
                            <div className="input-suffix">
                              <img
                                className="search-icon"
                                alt=""
                                src="/search.svg"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="componentsdropdown-trigger-wi-wrapper">
                    <div className="componentsdropdown-trigger-wi">
                      <div className="dropdown-trigger">
                        <div className="button3">
                          <div className="icon23">
                            <div className="width-change-size-here36">
                              <div className="ignore146" />
                              <div className="ignore147" />
                            </div>
                            <div className="icon-wrapper-h36">
                              <div className="height-change-size-here36">
                                <div className="ignore148" />
                                <div className="ignore149" />
                              </div>
                              <img
                                className="icon-wrapper37"
                                alt=""
                                src="/iconwrapper-32@2x.png"
                              />
                            </div>
                          </div>
                          <div className="text39">
                            <div className="text40">Todos</div>
                          </div>
                          <div className="icon-21">
                            <div className="width-change-size-here37">
                              <div className="ignore150" />
                              <div className="ignore151" />
                            </div>
                            <div className="icon-wrapper-h37">
                              <div className="height-change-size-here37">
                                <div className="ignore152" />
                                <div className="ignore153" />
                              </div>
                              <img
                                className="icon-wrapper38"
                                alt=""
                                src="/iconwrapper-32@2x.png"
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="box" />
                      <div className="zero-height">
                        <div className="dropdown-menu1">
                          <div className="componentsdropdown-menu-item">
                            <div className="wrapper18">
                              <div className="content1">
                                <div className="icon24">
                                  <div className="width-change-size-here38">
                                    <div className="ignore154" />
                                    <div className="ignore155" />
                                  </div>
                                  <div className="icon-wrapper-h38">
                                    <div className="height-change-size-here38">
                                      <div className="ignore156" />
                                      <div className="ignore157" />
                                    </div>
                                    <img
                                      className="icon-wrapper39"
                                      alt=""
                                      src="/iconwrapper-34@2x.png"
                                    />
                                  </div>
                                </div>
                                <div className="text41">
                                  <div className="text42">Viseu</div>
                                </div>
                              </div>
                              <div className="layout-blockshorizontal1">
                                <div className="layout-blocksbase">
                                  <div className="swap-label">
                                    <span className="swap-label-txt">
                                      <p className="p">◇</p>
                                      <p className="swap">Swap</p>
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="arrow17">
                              <div className="width-change-size-here39">
                                <div className="ignore158" />
                                <div className="ignore159" />
                              </div>
                              <div className="icon-wrapper-h39">
                                <div className="height-change-size-here39">
                                  <div className="ignore160" />
                                  <div className="ignore161" />
                                </div>
                                <img
                                  className="icon-wrapper40"
                                  alt=""
                                  src="/iconwrapper-35@2x.png"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="componentsdropdown-menu-item1">
                            <div className="wrapper19">
                              <div className="content2">
                                <div className="icon25">
                                  <div className="width-change-size-here40">
                                    <div className="ignore162" />
                                    <div className="ignore163" />
                                  </div>
                                  <div className="icon-wrapper-h40">
                                    <div className="height-change-size-here40">
                                      <div className="ignore164" />
                                      <div className="ignore165" />
                                    </div>
                                    <img
                                      className="icon-wrapper41"
                                      alt=""
                                      src="/iconwrapper-34@2x.png"
                                    />
                                  </div>
                                </div>
                                <div className="text43">
                                  <div className="text44">Teste Região</div>
                                </div>
                              </div>
                              <div className="layout-blockshorizontal11">
                                <div className="layout-blocksbase1">
                                  <div className="swap-label1">
                                    <span className="swap-label-txt1">
                                      <p className="p1">◇</p>
                                      <p className="swap1">Swap</p>
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="arrow18">
                              <div className="width-change-size-here41">
                                <div className="ignore166" />
                                <div className="ignore167" />
                              </div>
                              <div className="icon-wrapper-h41">
                                <div className="height-change-size-here41">
                                  <div className="ignore168" />
                                  <div className="ignore169" />
                                </div>
                                <img
                                  className="icon-wrapper42"
                                  alt=""
                                  src="/iconwrapper-35@2x.png"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="componentsdropdown-menu-item2">
                            <div className="wrapper20">
                              <div className="content3">
                                <div className="icon26">
                                  <div className="width-change-size-here42">
                                    <div className="ignore170" />
                                    <div className="ignore171" />
                                  </div>
                                  <div className="icon-wrapper-h42">
                                    <div className="height-change-size-here42">
                                      <div className="ignore172" />
                                      <div className="ignore173" />
                                    </div>
                                    <img
                                      className="icon-wrapper43"
                                      alt=""
                                      src="/iconwrapper-34@2x.png"
                                    />
                                  </div>
                                </div>
                                <div className="text45">
                                  <div className="text46">Coimbra</div>
                                </div>
                              </div>
                              <div className="layout-blockshorizontal12">
                                <div className="layout-blocksbase2">
                                  <div className="swap-label2">
                                    <span className="swap-label-txt2">
                                      <p className="p2">◇</p>
                                      <p className="swap2">Swap</p>
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="arrow19">
                              <div className="width-change-size-here43">
                                <div className="ignore174" />
                                <div className="ignore175" />
                              </div>
                              <div className="icon-wrapper-h43">
                                <div className="height-change-size-here43">
                                  <div className="ignore176" />
                                  <div className="ignore177" />
                                </div>
                                <img
                                  className="icon-wrapper44"
                                  alt=""
                                  src="/iconwrapper-35@2x.png"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="componentsdropdown-menu-item3">
                            <div className="wrapper21">
                              <div className="content4">
                                <div className="icon27">
                                  <div className="width-change-size-here44">
                                    <div className="ignore178" />
                                    <div className="ignore179" />
                                  </div>
                                  <div className="icon-wrapper-h44">
                                    <div className="height-change-size-here44">
                                      <div className="ignore180" />
                                      <div className="ignore181" />
                                    </div>
                                    <img
                                      className="icon-wrapper45"
                                      alt=""
                                      src="/iconwrapper-34@2x.png"
                                    />
                                  </div>
                                </div>
                                <div className="text47">
                                  <div className="text48">Mostrar Todos</div>
                                </div>
                              </div>
                              <div className="layout-blockshorizontal13">
                                <div className="layout-blocksbase3">
                                  <div className="swap-label3">
                                    <span className="swap-label-txt3">
                                      <p className="p3">◇</p>
                                      <p className="swap3">Swap</p>
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="arrow20">
                              <div className="width-change-size-here45">
                                <div className="ignore182" />
                                <div className="ignore183" />
                              </div>
                              <div className="icon-wrapper-h45">
                                <div className="height-change-size-here45">
                                  <div className="ignore184" />
                                  <div className="ignore185" />
                                </div>
                                <img
                                  className="icon-wrapper46"
                                  alt=""
                                  src="/iconwrapper-35@2x.png"
                                />
                              </div>
                            </div>
                          </div>
                          <div className="min-width">
                            <div className="start" />
                            <div className="end" />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </nav>
                <div className="table-example">
                  <div className="star-shape">
                    <div className="text-cell">
                      <div className="text49">#</div>
                    </div>
                    <div className="text-cell1">
                      <div className="triangle-set">1</div>
                    </div>
                    <div className="text-cell2">
                      <div className="text50">2</div>
                    </div>
                    <div className="text-cell3">
                      <div className="path-crossing">3</div>
                    </div>
                    <div className="text-cell4">
                      <div className="text51">4</div>
                    </div>
                    <div className="text-cell5">
                      <div className="text52">5</div>
                    </div>
                    <div className="text-cell6">
                      <div className="star-spreading">6</div>
                    </div>
                    <div className="text-cell7">
                      <div className="text53">7</div>
                    </div>
                  </div>
                  <div className="star-shape1">
                    <div className="text-cell8">
                      <div className="text54">Descrição</div>
                    </div>
                    <div className="text-cell9">
                      <div className="text55">Campo de Coimbroes</div>
                    </div>
                    <div className="text-cell10">
                      <div className="text56">Campo da Amadora</div>
                    </div>
                    <div className="text-cell11">
                      <div className="text57">Campo Martim Moniz</div>
                    </div>
                    <div className="text-cell12">
                      <div className="text58">Campo da Ria</div>
                    </div>
                    <div className="text-cell13">
                      <div className="text59">Campo de Gaia</div>
                    </div>
                    <div className="text-cell14">
                      <div className="text60">Campo de Alfragide</div>
                    </div>
                    <div className="text-cell15">
                      <div className="text61">Campo Freixo de Espadas</div>
                    </div>
                  </div>
                  <div className="star-shape2">
                    <div className="text-cell16">
                      <div className="text62">Utilizadores</div>
                    </div>
                    <div className="text-cell17">
                      <div className="text63">2798</div>
                    </div>
                    <div className="text-cell18">
                      <div className="text64">4600</div>
                    </div>
                    <div className="text-cell19">
                      <div className="text65">4846</div>
                    </div>
                    <div className="text-cell20">
                      <div className="text66">9151</div>
                    </div>
                    <div className="text-cell21">
                      <div className="text67">6025</div>
                    </div>
                    <div className="text-cell22">
                      <div className="text68">6065</div>
                    </div>
                    <div className="text-cell23">
                      <div className="text69">9261</div>
                    </div>
                  </div>
                  <div className="text-cell-parent">
                    <div className="text-cell24">
                      <div className="text70">Data de criação</div>
                    </div>
                    <div className="text-cell25">
                      <div className="text71">02/07/1971</div>
                    </div>
                    <div className="text-cell26">
                      <div className="text72">28/03/1968</div>
                    </div>
                    <div className="text-cell27">
                      <div className="text73">12/08/1994</div>
                    </div>
                    <div className="text-cell28">
                      <div className="text74">02/01/1980</div>
                    </div>
                    <div className="text-cell29">
                      <div className="text75">27/11/1987</div>
                    </div>
                    <div className="text-cell30">
                      <div className="text76">22/08/1969</div>
                    </div>
                    <div className="text-cell31">
                      <div className="text77">20/06/1988</div>
                    </div>
                  </div>
                  <div className="star-shape3">
                    <div className="text-cell32">
                      <div className="text78">Localidade</div>
                    </div>
                    <div className="text-cell33">
                      <div className="text79">Coimbroes</div>
                    </div>
                    <div className="text-cell34">
                      <div className="text80">Amadora</div>
                    </div>
                    <div className="text-cell35">
                      <div className="text81">Martim Moniz</div>
                    </div>
                    <div className="text-cell36">
                      <div className="text82">Ria</div>
                    </div>
                    <div className="text-cell37">
                      <div className="text83">Gaia</div>
                    </div>
                    <div className="text-cell38">
                      <div className="text84">Alfragide</div>
                    </div>
                    <div className="text-cell39">
                      <div className="text85">Freixo de Espada</div>
                    </div>
                  </div>
                  <div className="star-shape4">
                    <div className="text-cell40">
                      <div className="text86">Status</div>
                    </div>
                    <div className="text-cell41">
                      <div className="button4">
                        <img
                          className="plus-circle-icon2"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                        <div className="button-label1">Active</div>
                        <img
                          className="plus-circle-icon3"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell42">
                      <div className="button5">
                        <img
                          className="plus-circle-icon4"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                        <div className="button-label2">Inactive</div>
                        <img
                          className="plus-circle-icon5"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell43">
                      <div className="button6">
                        <img
                          className="plus-circle-icon6"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                        <div className="button-label3">Active</div>
                        <img
                          className="plus-circle-icon7"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell44">
                      <div className="button7">
                        <img
                          className="plus-circle-icon8"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                        <div className="button-label4">Active</div>
                        <img
                          className="plus-circle-icon9"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell45">
                      <div className="button8">
                        <img
                          className="plus-circle-icon10"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                        <div className="button-label5">Inactive</div>
                        <img
                          className="plus-circle-icon11"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell46">
                      <div className="button9">
                        <img
                          className="plus-circle-icon12"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                        <div className="button-label6">Inactive</div>
                        <img
                          className="plus-circle-icon13"
                          alt=""
                          src="/pluscircle2.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell47">
                      <div className="button10">
                        <img
                          className="plus-circle-icon14"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                        <div className="button-label7">Active</div>
                        <img
                          className="plus-circle-icon15"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="star-shape5">
                    <div className="text-cell48">
                      <div className="text87">Status</div>
                    </div>
                    <div className="text-cell49">
                      <div
                        className="button11"
                        onClick={onButtonContainer2Click}
                      >
                        <img
                          className="edit-icon"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label8" />
                        <img
                          className="plus-circle-icon16"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell50">
                      <div className="button12">
                        <img
                          className="edit-icon1"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label9" />
                        <img
                          className="plus-circle-icon17"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell51">
                      <div className="button13">
                        <img
                          className="edit-icon2"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label10" />
                        <img
                          className="plus-circle-icon18"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell52">
                      <div className="button14">
                        <img
                          className="edit-icon3"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label11" />
                        <img
                          className="plus-circle-icon19"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell53">
                      <div className="button15">
                        <img
                          className="edit-icon4"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label12" />
                        <img
                          className="plus-circle-icon20"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell54">
                      <div className="button16">
                        <img
                          className="edit-icon5"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label13" />
                        <img
                          className="plus-circle-icon21"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                    <div className="text-cell55">
                      <div className="button17">
                        <img
                          className="edit-icon6"
                          loading="lazy"
                          alt=""
                          src="/edit.svg"
                        />
                        <div className="button-label14" />
                        <img
                          className="plus-circle-icon22"
                          alt=""
                          src="/pluscircle1.svg"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="group-div">
                <div className="frame-child4" />
                <div className="pagination">
                  <div className="content5">
                    <div className="texttext">
                      <div className="data-processor">Total 85 items</div>
                    </div>
                    <div className="page-items">
                      <div className="componentspagination-prev">
                        <div className="icon28">
                          <div className="width-change-size-here46">
                            <div className="ignore186" />
                            <div className="ignore187" />
                          </div>
                          <div className="icon-wrapper-h46">
                            <div className="height-change-size-here46">
                              <div className="ignore188" />
                              <div className="ignore189" />
                            </div>
                            <img
                              className="icon-wrapper47"
                              loading="lazy"
                              alt=""
                              src="/iconwrapper-42@2x.png"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="componentspagination-item">
                        <div className="texttext1">
                          <div className="text88">1</div>
                        </div>
                      </div>
                      <div className="componentspagination-item-ell">
                        <div className="icon29">
                          <div className="width-change-size-here47">
                            <div className="ignore190" />
                            <div className="ignore191" />
                          </div>
                          <div className="icon-wrapper-h47">
                            <div className="height-change-size-here47">
                              <div className="ignore192" />
                              <div className="ignore193" />
                            </div>
                            <img
                              className="icon-wrapper48"
                              loading="lazy"
                              alt=""
                              src="/iconwrapper-43@2x.png"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="componentspagination-item1">
                        <div className="texttext2">
                          <div className="text89">4</div>
                        </div>
                      </div>
                      <div className="componentspagination-item2">
                        <div className="texttext3">
                          <div className="text90">5</div>
                        </div>
                      </div>
                      <div className="componentspagination-item3">
                        <div className="texttext4">
                          <div className="text91">6</div>
                        </div>
                      </div>
                      <div className="componentspagination-item4">
                        <div className="texttext5">
                          <div className="text92">7</div>
                        </div>
                      </div>
                      <div className="componentspagination-item5">
                        <div className="texttext6">
                          <div className="text93">8</div>
                        </div>
                      </div>
                      <div className="componentspagination-item-ell1">
                        <div className="icon30">
                          <div className="width-change-size-here48">
                            <div className="ignore194" />
                            <div className="ignore195" />
                          </div>
                          <div className="icon-wrapper-h48">
                            <div className="height-change-size-here48">
                              <div className="ignore196" />
                              <div className="ignore197" />
                            </div>
                            <img
                              className="icon-wrapper49"
                              loading="lazy"
                              alt=""
                              src="/iconwrapper-43@2x.png"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="componentspagination-item6">
                        <div className="texttext7">
                          <div className="text94">20</div>
                        </div>
                      </div>
                      <div className="componentspagination-next">
                        <div className="icon31">
                          <div className="width-change-size-here49">
                            <div className="ignore198" />
                            <div className="ignore199" />
                          </div>
                          <div className="icon-wrapper-h49">
                            <div className="height-change-size-here49">
                              <div className="ignore200" />
                              <div className="ignore201" />
                            </div>
                            <img
                              className="icon-wrapper50"
                              loading="lazy"
                              alt=""
                              src="/iconwrapper-45@2x.png"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="pagination-options">
                    <div className="select">
                      <div className="wrapper22">
                        <div className="selection-item">
                          <div className="placeholder">
                            <div className="text95">10 / page</div>
                          </div>
                        </div>
                        <div className="input-suffix1">
                          <div className="icon-wrapper51">
                            <div className="width-change-size-here50">
                              <div className="ignore202" />
                              <div className="ignore203" />
                            </div>
                            <div className="icon-wrapper-h50">
                              <div className="height-change-size-here50">
                                <div className="ignore204" />
                                <div className="ignore205" />
                              </div>
                              <img
                                className="icon-wrapper52"
                                alt=""
                                src="/iconwrapper-46@2x.png"
                              />
                            </div>
                          </div>
                        </div>
                        <div className="icon-down">
                          <div className="width-change-size-here51">
                            <div className="ignore206" />
                            <div className="ignore207" />
                          </div>
                          <div className="icon-wrapper-h51">
                            <div className="height-change-size-here51">
                              <div className="ignore208" />
                              <div className="ignore209" />
                            </div>
                            <img
                              className="icon-select-down"
                              alt=""
                              src="/-iconselectdown.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="box1" />
                      <div className="zero-height1">
                        <div className="select-options">
                          <div className="componentsselect-optionsingl">
                            <div className="title4">Option 01</div>
                          </div>
                          <div className="componentsselect-optionsingl1">
                            <div className="title5">Option 02</div>
                          </div>
                          <div className="componentsselect-optionsingl2">
                            <div className="title6">Option 03</div>
                          </div>
                          <div className="componentsselect-optionsingl3">
                            <div className="title7">Option 04</div>
                          </div>
                          <div className="componentsselect-optionsingl4">
                            <div className="title8">Option 05</div>
                          </div>
                          <div className="componentsselect-optionsingl5">
                            <div className="title9">Option 06</div>
                          </div>
                          <div className="componentsselect-optionsingl6">
                            <div className="title10">Option 07</div>
                          </div>
                          <div className="componentsselect-optionsingl7">
                            <div className="title11">Option 08</div>
                          </div>
                          <div className="componentsselect-optionsingl8">
                            <div className="title12">Option 09</div>
                          </div>
                          <div className="componentsselect-optionsingl9">
                            <div className="title13">Option 10</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="quick-jumper">
                      <div className="texttext8">
                        <div className="text96">Go to</div>
                      </div>
                      <div className="input3">
                        <div className="input-base1">
                          <div className="placeholder1">
                            <div className="input-prefix1">
                              <div className="icon-wrapper53">
                                <div className="width-change-size-here52">
                                  <div className="ignore210" />
                                  <div className="ignore211" />
                                </div>
                                <div className="icon-wrapper-h52">
                                  <div className="height-change-size-here52">
                                    <div className="ignore212" />
                                    <div className="ignore213" />
                                  </div>
                                  <img
                                    className="icon-wrapper54"
                                    alt=""
                                    src="/iconwrapper-47@2x.png"
                                  />
                                </div>
                              </div>
                            </div>
                            <div className="placeholder2" />
                          </div>
                          <div className="spacer3">
                            <div className="ignore214" />
                            <div className="ignore215" />
                          </div>
                          <div className="input-suffix2">
                            <div className="icon-wrapper55">
                              <div className="width-change-size-here53">
                                <div className="ignore216" />
                                <div className="ignore217" />
                              </div>
                              <div className="icon-wrapper-h53">
                                <div className="height-change-size-here53">
                                  <div className="ignore218" />
                                  <div className="ignore219" />
                                </div>
                                <img
                                  className="icon-wrapper56"
                                  alt=""
                                  src="/iconwrapper-46@2x.png"
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default Polos;
